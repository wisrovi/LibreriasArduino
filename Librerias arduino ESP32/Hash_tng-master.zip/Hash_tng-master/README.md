Port for Hash library from https://github.com/esp8266/Arduino/libraries/Hash
commit d6f1f0d to ESP32.

This is an experimental port that should work on ESP8266 and ESP32. This is NOT
an official repo supported by Espressif. Do not depend on this code for
anything important or expect it to be updated. Once the official repo is
created, this repo will be deleted.
