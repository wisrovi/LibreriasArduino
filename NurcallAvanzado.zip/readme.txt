


Estas librerias, asi como el codigo de cada una, fueron creadas por 



William S. Rodriguez Villamizar - ingeniero Electronico UDI

La duracion de la creacion del codigo fue del 10MArzo2015 al 31Diciembre2015 

en labores de la FCV (www.FCV.org)



Gracias Dios Santisiomo por darme esta oportunidad, llenarme de bendiciones y darme las capacidades para lograr este proyecto en mi vida.

Le agradezco a mi familia por acompa�arme en todo el camino, educarme en todos los aspectos, aconsejarme y acompa�arme.

Le otorgo un agradecimiento especial al Ingeniero Miguel Angel Jurado Arenales - Ingeniero Electronico, quien vio en mi las capacidades, por las cuales me dio las primeras oportunidades para mostrar mis talentos, con lo cual, los inicios de mi carrera fueron gracias a �l.
