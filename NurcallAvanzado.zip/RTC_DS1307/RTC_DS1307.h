
/*
Estas librerias, asi como el codigo de cada una, fueron creadas por 



William S. Rodriguez Villamizar - ingeniero Electronico UDI

La duracion de la creacion del codigo fue del 10MArzo2015 al 31Diciembre2015 

en labores de la FCV (www.FCV.org)



Gracias Dios Santisiomo por darme esta oportunidad, llenarme de bendiciones y darme las capacidades para lograr este proyecto en mi vida.

Le agradezco a mi familia por acompa�arme en todo el camino, educarme en todos los aspectos, aconsejarme y acompa�arme.

Le otorgo un agradecimiento especial al Ingeniero Miguel Angel Jurado Arenales - Ingeniero Electronico, quien vio en mi las capacidades, por las cuales me dio las primeras oportunidades para mostrar mis talentos, con lo cual, los inicios de mi carrera fueron gracias a �l.
*/

#include <Wire.h>
#include "RTClib.h"



#if defined(ARDUINO_ARCH_SAMD)
   #define Serial SerialUSB
#endif



RTC_DS1307 rtc;

String CorreccionDosDigitos(int info){
      String info2 = ""; 
      if(info < 10){ info2.concat(  String("0") ); }
      info2.concat(info);
      return info2;
}

String Read_DS1307(void){
  char daysOfTheWeek[7][12] = {"Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"};
  String data = "";
  DateTime now = rtc.now();

  //data.concat(  " ("  );
  //data.concat(  daysOfTheWeek[now.dayOfTheWeek()]  );
  //data.concat(  ") - "  );  
  data.concat(  now.year()    );data.concat(  "/"  );
  data.concat(  CorreccionDosDigitos(  now.month()  ) );data.concat(  "/"  );
  data.concat(  CorreccionDosDigitos(  now.day()    ) );data.concat(  " "  );
  data.concat(  CorreccionDosDigitos(  now.hour()   ) );data.concat(  ":"  );
  data.concat(  CorreccionDosDigitos(  now.minute() ) );data.concat(  ":"  );
  data.concat(  CorreccionDosDigitos(  now.second() ) );
  data.concat(  "\n"  );  
  return data;
}

void configure_RTCDS1307(void){
  if (! rtc.begin()) {
    DPRINTLN("Couldn't find RTC");
    while (1);
  } 
}

void configurar_grabar_hora(void){
	#ifndef ESP8266
	while (!Serial); // for Leonardo/Micro/Zero
	#endif

	Serial.begin(9600);
	if (! rtc.begin()) {
		DPRINTLN("Couldn't find RTC");
		while (1);
	}

	if (! rtc.isrunning()) {
		DPRINTLN("RTC is NOT running!");
	}else{
		DPRINTLN("RTC configurated!");		
	}
	rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
}

void ajustarHoraPrimeraVez(int AAAA, int MM){
	DateTime dt6 (  AAAA,
					MM,
					12,
					9,
					30,
					15        );
	
	rtc.adjust(dt6);
}

void actualizarRTC(String dateServer){
	String RTC_AAAA = dateServer.substring(0, 4);
	String RTC_MM = dateServer.substring(4, 6);
	String RTC_DD = dateServer.substring(6, 8);
	String RTC_HH = dateServer.substring(8, 10);
	String RTC_MIN = dateServer.substring(10, 12);
	String RTC_SS = dateServer.substring(12, 14);
	
	int aaaa = RTC_AAAA.toInt();
	int mes = RTC_MM.toInt();
	int dia = RTC_DD.toInt();
	int hora = RTC_HH.toInt();
	int minutos = RTC_MIN.toInt();
	int segundos = RTC_SS.toInt() + 10;
	
	if(segundos >= 60){
		segundos = segundos - 60;
		minutos++;
		if(minutos>=60){
			minutos = minutos - 60;
			hora++;
			if(hora>=24){
				hora = hora - 24;
				dia++;	
			}
		}
	}
	
	DPRINT("RTC a guardar: ");DPRINT(RTC_AAAA);DPRINT("/");
	DPRINT(RTC_MM);DPRINT("/");
	DPRINT(RTC_DD);DPRINT("-");
	DPRINT(RTC_HH);DPRINT(":");
	DPRINT(RTC_MIN);DPRINT(":");
	DPRINT(RTC_SS);DPRINTLN(".");
	
	
	DateTime dt6 (	RTC_AAAA.toInt(),
					RTC_MM.toInt(),
					RTC_DD.toInt(),
					RTC_HH.toInt(),
					RTC_MIN.toInt(),
					RTC_SS.toInt()        );
	rtc.adjust(dt6);
	
}