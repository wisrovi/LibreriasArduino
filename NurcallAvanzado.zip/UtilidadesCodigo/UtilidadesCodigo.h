
/*
Estas librerias, asi como el codigo de cada una, fueron creadas por 



William S. Rodriguez Villamizar - ingeniero Electronico UDI

La duracion de la creacion del codigo fue del 10MArzo2015 al 31Diciembre2015 

en labores de la FCV (www.FCV.org)



Gracias Dios Santisimo por darme esta oportunidad, llenarme de bendiciones y darme las capacidades para lograr este proyecto en mi vida.

Le agradezco a mi familia por acompa�arme en todo el camino, educarme en todos los aspectos, aconsejarme y acompa�arme.

Le otorgo un agradecimiento especial al Ingeniero Miguel Angel Jurado Arenales - Ingeniero Electronico, quien vio en mi las capacidades, por las cuales me dio las primeras oportunidades para mostrar mis talentos, con lo cual, los inicios de mi carrera fueron gracias a �l.
*/








/*
 * UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo
 * UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo
 * UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo
 * UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo
 * UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo
 * UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo
 * UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo
 * UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo
 * UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo
 * UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo
 * UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo
 * UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo UtilidadesCodigo
 */

//**************************************************************************************************************************************************************************** 
 void actualizo_lampara(void){
	prendoAzul_siHayAzul();    
    prendoRojo_siHayRojo();  
    prendoVerde_siHayVerde();
    prendoBlanco_siHayBlanco();  
}
 
 
 
 
//**************************************************************************************************************************************************************************** 
void procesarEthernet(String mensaje){ 
   if(mensaje != "void" && mensaje != " "){  
	    impresion1(mensaje);   
		actualizarVariablesConMensajeRecibidoEthernet(mensaje );		  		
        actualizo_lampara();		 		   
    }
}

//**************************************************************************************************************************************************************************** 
void procesarRTAWerServlet(char c){  
  if(esperarRespuestaWebServlet==1){
	  switch(c){
			case 'T':{	verificacionComunicacionCorrecta();								}break;
			case 'F':{	ordenDirectaDelServidorParaIndependizarme();					}break;
			default:{	BusquedaErrorMensajeRecibido_ParaIndependizarElSistema(c);		}break;
	  }        	  
  }   
}

//**************************************************************************************************************************************************************************** 
void revision_cambios_pulsadores(int pulsadores,int esclavo){
	TraduscoInformacionRecibidaPacienteComoPacienteFuncionando(esclavo); //si el paciente contesta = paciente funciona	
	int datoPulsadoresVisibles = lamparaAzul[esclavo-1] + lamparaRoja[esclavo-1]*2 + lamparaBlanca[esclavo-1]*4 + lamparaVerde[esclavo-1]*8;
	if(pulsadores != pulsadoresSlave[esclavo-1]  ||  pulsadores>=17 || pulsadores==2 || pulsadores!=datoPulsadoresVisibles){			
		BuscoCambiosPulsadoresParaInformarServidorPacientesYLampara(pulsadores , esclavo);
		AlmacenoEstadoPulsadoresDelPacienteEnUnaVariable(esclavo, pulsadores);	
	}	
}


//**************************************************************************************************************************************************************************** 
void procesarRS485(String recibido_RS485){
  if(recibido_RS485 != "00"){
      char recibido_por_RS485[3] = {'0','0','0'};
      recibido_RS485.toCharArray(recibido_por_RS485,3);
      int esclavo = recibido_por_RS485[1] - 48;//el 48 es equivalente a '0' en la tabla ASCII 
      int pulsadores = recibido_por_RS485[0] - 33;//el 33 es equivalente a '!' en la tabla ASCII 
      
	  if(pulsadores==57){
		  esclavo = -3;
		  DPRINTLN("pacientes reiniciados");
		  delay(1000);		
		  if(reinicioLampara == 1){Reset_AVR();} 
	  }else{	  
		  impresion2(recibido_por_RS485[0], recibido_por_RS485[1]);
		  if(esclavo > 0){
			    impresion3(pulsadores, esclavo);		
				revision_cambios_pulsadores(pulsadores,esclavo);
				actualizo_lampara();			
				procesoSecreto1(recibido_por_RS485[0] );				      
		  }   
	  }
  } 
}


/*
 * hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware 
 * hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware 
 * hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware 
 * hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware 
 * hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware 
 * hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware 
 * hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware 
 * hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware 
 * hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware 
 * hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware 
 * hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware hardware 
 */


//////////////////////// configurar lampara  ////////////////////////////////////////////////////////////////////////////

//**************************************************************************************************************************************************************************** 
void configurarLampara(void){
	 ledsComoSalidas();
     configuroParlante();
     ledsMultipropositoComoSalidas();
	 configuroMicroSD();
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




/*
 * WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC
 * WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC
 * WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC
 * WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC
 * WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC
 * WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC
 * WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC
 * WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC
 * WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC
 * WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC
 * WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC
 * WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC
 * WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC      WC
 */



//**************************************************************************************************************************************************************************** 
void ProcesosWC(int habilitarWC1, int habilitarWC2){	
	if( EEPROM.read(5) == 0 ){ 
		if(habilitarWC1==1){    leerWC();   informarCambiosWC1Pacientes(); 	}
		if(habilitarWC2==1){    leerWC2();  informarCambiosWC2Pacientes(); 	}
		enciendoParpadeoWC_si_hayWCActivos();
	}else{
		WC1 = 0;
		WC2 = 0;
	}     
}
 
void informarWC(void){
	enviarServidorWC1Activo_siEstaActivo();	
	enviarServidorWC2Activo_siEstaActivo();  
}

void cerrarComunicacionWebServlet(void){
	if(cerrarComunServidor==1){
		cerrarComunServidor=0;
		client2.stop();     
	}	
}

void OtrosProcesosDeTiempo(void){
	procesadorTiempo();	
	delay(1);
	informarWC();
	cerrarComunicacionWebServlet();
}