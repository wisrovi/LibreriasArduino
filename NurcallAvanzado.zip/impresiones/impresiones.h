
/*
Estas librerias, asi como el codigo de cada una, fueron creadas por 



William S. Rodriguez Villamizar - ingeniero Electronico UDI

La duracion de la creacion del codigo fue del 10MArzo2015 al 31Diciembre2015 

en labores de la FCV (www.FCV.org)



Gracias Dios Santisiomo por darme esta oportunidad, llenarme de bendiciones y darme las capacidades para lograr este proyecto en mi vida.

Le agradezco a mi familia por acompa�arme en todo el camino, educarme en todos los aspectos, aconsejarme y acompa�arme.

Le otorgo un agradecimiento especial al Ingeniero Miguel Angel Jurado Arenales - Ingeniero Electronico, quien vio en mi las capacidades, por las cuales me dio las primeras oportunidades para mostrar mis talentos, con lo cual, los inicios de mi carrera fueron gracias a �l.
*/


/*
 * impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones
 * impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones
 * impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones
 * impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones
 * impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones
 * impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones
 * impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones
 * impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones
 * impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones
 * impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones impresiones
 */

void impresion1(String mensaje){
	if(imprimir==1){
		DPRINTLN();
		DPRINTLN("datos ethernet: ");
		DPRINT("mensaje: ");DPRINT(mensaje);
		DPRINT(" - ");DPRINT(" tama�o: "); DPRINTLN(mensaje.length());
	}
}

void impresion2(char c, char d){
	if(imprimir==1){
		DPRINT("datos RS485: ");DPRINT(c);
		DPRINTLN(d);
	}
}

void impresion3(int c, int d){
	if(imprimir==1){
		DPRINT("pulsadores: ");DPRINT(c,BIN);
		DPRINT(" - slave: ");DPRINTLN(d);
	}
}

void impresion4(void){	
	if(imprimir==1){
		DPRINTLN("esclavos reiniciados!!");
	}
}

void impresion5(void){
	if(imprimir==1){
		DPRINT("WC1: ");DPRINTLN(WC1);
	}
}

void impresion6(void){
	if(imprimir==1){
		DPRINT("WC2: ");DPRINTLN(WC2);
	}
}

void impresion7(void){
	if(imprimir==1){
		DPRINTLN("[0] sistema normal... ");
	}
}

void impresion8(void){
	if(imprimir==1){
		DPRINTLN("[0] sistema normal... ");
	}
}

void impresion9(void){
	DPRINTLN("[1 - procesarRTAWerServlet] sistema independiente... ");
}

void impresion10(int a, int b, int c, int d, int e, int esclavo){
	if(imprimir==1){
		DPRINT("azulado: ");DPRINTLN(a);
		DPRINT("rojiso: ");DPRINTLN(b);
		DPRINT("blancusco: ");DPRINTLN(c);
		DPRINT("verdusco: ");DPRINTLN(d);
		DPRINT("grisaceo: ");DPRINTLN(e);
		DPRINT("slave: ");DPRINTLN(esclavo);DPRINTLN();
	}
}

void impresion11(int imprimir){
	if(imprimir==1){
		DPRINTLN();
		DPRINT("puerto: ");DPRINTLN(puerto);
		DPRINT("URL: ");
		for(int i=0;i<20;i++){
			DPRINT(URL[i]);
		}DPRINTLN();
		DPRINT("webService: ");DPRINTLN(webService);
		DPRINT("Method1: ");DPRINTLN(Method1);
		DPRINT("Method2: ");DPRINTLN(Method2);
		DPRINT("Method3: ");DPRINTLN(Method3);
		DPRINT("numero_Slaves: ");DPRINTLN(numero_Slaves);
		DPRINT("number_WC: ");DPRINTLN(number_WC);
		DPRINT("MAC: ");for(int i=0;i<=5;i++){DPRINT(mac[i],HEX);DPRINT(":"); }DPRINTLN();
		DPRINTLN();
	}
}

void impresion12(int selector){
	if(imprimir==1){
		DPRINT("enviando informacion a esclavo ");DPRINTLN(selector);
	}
}

void impresion13(void){
	DPRINTLN("\n[0 - TiempoRetornoServidor] sistema independiente... ");
}

void impresion14(int j){
	if(imprimir==1){
		DPRINT("SHIPP: ");DPRINT(lamparaRoja[j]);DPRINT("-");DPRINTLN(AdressSlave[j+1]);	
	}
}