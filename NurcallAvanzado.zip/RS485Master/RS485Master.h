
/*
Estas librerias, asi como el codigo de cada una, fueron creadas por 



William S. Rodriguez Villamizar - ingeniero Electronico UDI

La duracion de la creacion del codigo fue del 10MArzo2015 al 31Diciembre2015 

en labores de la FCV (www.FCV.org)



Gracias Dios Santisiomo por darme esta oportunidad, llenarme de bendiciones y darme las capacidades para lograr este proyecto en mi vida.

Le agradezco a mi familia por acompa�arme en todo el camino, educarme en todos los aspectos, aconsejarme y acompa�arme.

Le otorgo un agradecimiento especial al Ingeniero Miguel Angel Jurado Arenales - Ingeniero Electronico, quien vio en mi las capacidades, por las cuales me dio las primeras oportunidades para mostrar mis talentos, con lo cual, los inicios de mi carrera fueron gracias a �l.
*/

#include <SoftwareSerial.h>
SoftwareSerial RS485(6, 7); // RX, TX //AUNQUE EL RX SE CONFIGURE POR ESTA CLASE, EL PIN 6 EN ESTE ATMEGA 2560 NO TIENE HARDWARE PARA REALIZAR DETECCION POR INTERRUPCIONES Y NO HARA NADA (NO RECIBIRA). EN ESTE CODIGO DE LAMPARA PRINCIPAL LOS DATOS SE RECIBEN POR EL PIN 0 QUE USA LA ESCTRUCTURA HARDWARE "Serial." QUE A SU VEZ HACE CONJUNTO CON EL USB. 

//#define DEBUG_RS485

//**************************************************************************************************************************************************************************** 
void configurarRS485(int pin)
{
    RS485.begin(9600);
    pinMode(pin, OUTPUT);
    digitalWrite(pin, LOW);
}


//**************************************************************************************************************************************************************************** 
#define RS485_receive Serial
void enviar_RS485(char dat, char dat2, int pin)
{//dato,destino
	while(RS485_receive.available()){RS485_receive.read();}
	if (!RS485_receive.available())
	{
		conteoLecturasEnviadosRS485++;
		digitalWrite(pin, HIGH);
		delay(1);
		//Header
		RS485.write(0x5A);
		RS485.write(0xA5);
		//Datos
		RS485.write(dat);
		RS485.write(dat2);
		//Checksum XOR de lo que se pongan de datos
		RS485.write(dat^dat2);
		delay(1);
		digitalWrite(pin, LOW);
	}
}
//ultimoDatoRS485[i]*100 +  falloEnvioRS485[i]*10 +   ultimoDatoFalloEnvioRS485[i]      

//**************************************************************************************************************************************************************************** 

String recibidoRS485(int sel)
{
	String datoDepurado = "00";
	char dato[10] = {'0','0','0','0','0','0','0','0','0','0'};
	
	//Si hay algo para recibir recibe ...
	if (  RS485_receive.available()    )
	{
		int posicion_vector = 0;
		unsigned char header[2] = {'0','0'};
		char check_header = 0;
		while(RS485_receive.available())//Hasta que acabe todos los datos.
		{
			if(posicion_vector<10)//Solo le caben 10 datos a la variable "dato" se evita FALLO DE MEMORIA
			{
				if(check_header==1)//Cuando header este verificado hay si se pone a recibir datos
				{
					dato[posicion_vector] = RS485_receive.read();
					#ifdef DEBUG_RS485			
					if(header[0]!=0)
					{
						DPRINT("[");
						DPRINT(dato[posicion_vector],HEX);
						DPRINT("]");
					}
					#endif
					delay(1);//Delay para esperar que un nuevo dato tenga tiempo de recibirse, si no saldria rapido de este while y lo tomaria aparte como una nueva trama.
					posicion_vector++;
				}
				else//Se verifica el Header para evitar leer ruido que venga con un dato valido y genera mejor respuesta entre esclavo y maestro ya que no desperdicia el dato.
				{
					header[1] = header[0];//Se debe guardar lo del header[0] antes de cambiarlo en la siguiente linea y asi lograr un shift.
					header[0] = RS485_receive.read();
					#ifdef DEBUG_RS485
					if(header[0]!=0)
					{
						DPRINT("[");
						DPRINT(header[0],HEX);
						DPRINT("]");
					}
					#endif
					delay(1);//Delay para esperar que un nuevo dato tenga tiempo de recibirse, si no saldria rapido de este while y lo tomaria aparte como una nueva trama.
					if((header[1]==0x5A) && (header[0]==0xA5))
					{
						check_header = 1;
					}
				}
			}
			else
			{
				RS485_receive.read();//Limpie el buffer de todas formas.
			}
		}
		//if(header[0]!=0){DPRINTLN(".");}
		
		//Mientras el header se pudo recibir bien procese ... Ademas verifica checksum, es decir que los datos no esten corruptos.
		if(check_header==1 && dato[2]==(dato[0]^dato[1]))
		{
			if(dato[1]<'1' || dato[1]>'9')//Descarta datos invalidos .. NULLs y pacientes con ID menor o igual a cero o encima de su rango
			{
				if(sel ==1)
				{
					DPRINT("-R");
					//DPRINT("-Datos Invalidos [recibidoRS485]");//Datos erroneos, cumple el protocolo pero no es un dato valido
					conteoRuidoRS485++;
				}
			}
			else//No es basura, ni esta fuera de rango los datos que llegan
			{
				datoDepurado = "";datoDepurado.concat(dato[0]);datoDepurado.concat(dato[1]);
				conteoLecturasCorrectasRS485++;
				DPRINT( dato[0]   );DPRINT( dato[1]   );
				//DPRINT("RS485:");DPRINT(  (dato[0] -33   ),BIN);DPRINTLN(","+String(dato[1]));//ver los datos en binario
				
			}
		}
		else
		{
			if(check_header==1)
			{
				if(sel ==1)
				{
					DPRINT("-C");
					//DPRINTLN("-Error de Checksum [recibidoRS485]");
				}
				conteoRuidoRS485++;
			}
			else
			{
				if(header[0]!=0)//El null es el tipico ruido ya que el bus cae a cero solito asi que no cuenta.
				{
					if(sel ==1)
					{
						DPRINT("-H");
						//DPRINTLN("-Error de Header [recibidoRS485]");
					}
				}
			}
		}
	}
	return datoDepurado;
}
