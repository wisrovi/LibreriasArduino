
/*
Estas librerias, asi como el codigo de cada una, fueron creadas por 



William S. Rodriguez Villamizar - ingeniero Electronico UDI

La duracion de la creacion del codigo fue del 10MArzo2015 al 31Diciembre2015 

en labores de la FCV (www.FCV.org)



Gracias Dios Santisiomo por darme esta oportunidad, llenarme de bendiciones y darme las capacidades para lograr este proyecto en mi vida.

Le agradezco a mi familia por acompa�arme en todo el camino, educarme en todos los aspectos, aconsejarme y acompa�arme.

Le otorgo un agradecimiento especial al Ingeniero Miguel Angel Jurado Arenales - Ingeniero Electronico, quien vio en mi las capacidades, por las cuales me dio las primeras oportunidades para mostrar mis talentos, con lo cual, los inicios de mi carrera fueron gracias a �l.
*/





/*
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones
* TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones TraductorFunciones 
 */
 

void obtenerToken(void){
	//no tengo token (no registrado), busco token
	token = registrar(URL,puerto,mac[0],mac[1],mac[2],mac[3],mac[4],mac[5],webService,numero_Slaves,number_WC, Method1, Method2);
	
	//verifico la obtencion de token
	if(token.length() == 8){
		independiente=0;
	}else{
		sendTelegram("El servidor no ha entregado Token.");
	}
}

void salirIndependencia(void){
	//tengo token (ya registrado), envio 33 para salir de la independencia
	if(!banderaActualizarHoraCuandoActualizoFecha){
		EnviarWebservlet(33, 0, URL, puerto, token, Method1, Method2, Method3, webService);//slave, codigo, URL, puerto
	}	
}

void enviarSlavesFallando(void){
	if(token.length() == 8){  //confirmo que ya se encuentra matriculado
		for(int i=0;i<numero_Slaves;i++){
			if(vidaSlave[i] == '0'){
				EnviarWebservlet(34, i+1, URL, puerto, token, Method1, Method2, Method3, webService);//slave, codigo, URL, puerto
			}
		}
	}
}

boolean tengoToken(void){
	boolean dato = LOW;
	if(token.length() == 8){
		dato = HIGH;
	}
	return dato;
}

void conteo20mn(void){
	if(independiente==1){
		//bloque para intentar salir de la independencia
		if(   tengoToken()      ){
			salirIndependencia();
		}else{
			obtenerToken();
		}
	}else{
		enviarSlavesFallando();
	}
}

void TonoVerde1(void){
	analogWrite(9, 255);
}

void TonoVerde2(void){
	analogWrite(9, 90);
}

void TonoAmarillo1(void){
	analogWrite(9, 255);
}

void TonoAmarillo2(void){
	analogWrite(9, 125);
}

void ledEnVerde(void){
	analogWrite(8, 0);
	TonoVerde1();
}

void ledEnAmarillo(void){	
	analogWrite(8, 40);
	TonoAmarillo1();
}

void ledEnVacio(void){
	analogWrite(8, 0);
	analogWrite(9, 0);
}

void ledEnRojo(void){
	analogWrite(8, 255);
	analogWrite(9, 0);
}

void parpadeoTodoEstaBien(void){
	static int conteo_parpadeo = 0;
	conteo_parpadeo++;
	if(conteo_parpadeo>=5){
		conteo_parpadeo=0;
		if (independiente == 1){
			if(FuncionamientoSinServidor==HIGH){ledEnVacio();}
			else{
				TonoAmarillo2();
				if(NoPinVida==HIGH && token.length()==8){
					ledEnVerde();
					//DPRINTLN("NO pin de vida...");
				}								
			}
		}else{
			TonoVerde2();
		}
	}
}

void leerHoraServidor(void){
	int temporal = independiente;
	independiente = 0;
	EnviarWebservlet(35,0, URL, puerto, token, Method1, Method2, Method3, webService);
	independiente = temporal;
}

void pinVida(void){
	static int conteoNOpinVida = 0;
	if(temporalPinVidaServidor==1){
		temporalPinVidaServidor=0;
		conteoNOpinVida=0;
		NoPinVida = LOW;
	}else{
		conteoNOpinVida++;
		if(conteoNOpinVida>=3){
			conteoNOpinVida=0;independiente=1;DPRINTLN("\nDeteccion de servidor caido = sistema independiente");	
			NoPinVida = HIGH;
		}
	}
}

void menusOcultosCombinacionTeclas(void){
	//menuSecreto[0]=1;menuSecreto[1]=1;
	if(menuSecreto[0]==1){
		if(menuSecreto[1]==1){
			sendTelegram("Activacion menu secreto 1");
			menuSecreto[0]=0;			
			digitalWrite(LedAzul, HIGH);
			delay(100);
			digitalWrite(LedRojo, HIGH);
			delay(100);
			digitalWrite(LedVerde, HIGH);
			delay(100);
			digitalWrite(LedBlanco, HIGH);
			delay(100);					
			digitalWrite(LedAzul, LOW);
			delay(100);
			digitalWrite(LedRojo, LOW);
			delay(100);
			digitalWrite(LedVerde, LOW);
			delay(100);
			digitalWrite(LedBlanco, LOW);
			delay(100);			
			digitalWrite(LedAzul, HIGH);
			delay(100);
			digitalWrite(LedRojo, HIGH);
			delay(100);
			digitalWrite(LedVerde, HIGH);
			delay(100);
			digitalWrite(LedBlanco, HIGH);
			delay(100);
			for(int i=0;i<40;i++){
				digitalWrite(habilitadorZumbador, ONalarmasonora);
				tone(Zumbador, NOTE_C6, 100);
				delay(50);
			}			
			digitalWrite(habilitadorZumbador, OFFalarmasonora);
			int temporal = independiente;
			independiente = 0;
			EnviarWebservlet(34, 0, URL, puerto, token, Method1, Method2, Method3, webService);//slave, codigo, URL, puerto
			independiente = temporal;
			menuSecreto[0]=-1;			
		}
		if(menuSecreto[1]==2){
			sendTelegram("Activacion menu secreto 2");
			menuSecreto[0]=0;
			digitalWrite(LedVerde, HIGH);
			delay(300);
			digitalWrite(LedRojo, HIGH);
			delay(300);
			digitalWrite(LedBlanco, HIGH);
			delay(300);
			digitalWrite(LedAzul, HIGH);
			delay(300);			
		}
	}
}

void enviarCorreoWCDescompuesto(void){
	if(WC1_descompuesto==1){
		EnviarWebservlet(34, numero_Slaves + 1, URL, puerto, token, Method1, Method2, Method3, webService);//slave, codigo, URL, puerto
	}
	if(WC2_descompuesto==1){
		EnviarWebservlet(34, numero_Slaves + 2, URL, puerto, token, Method1, Method2, Method3, webService);//slave, codigo, URL, puerto
	}	
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////  procesos de tiempo   /////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void leds_indicadores(void){
	if(listaErrores[1]==1){     
		ledEnRojo();   
	}else {
		if (independiente == 1){
			if(FuncionamientoSinServidor==HIGH && FuncionamientoSinDHCP==HIGH){
				ledEnRojo();
			}else{
				ledEnAmarillo();
			}			
		}else{
			ledEnVerde();
		}
	}	
}

void proceso1segundos(void){	
	leds_indicadores();
}

void proceso10segundos(void){
	static int conteo1minuto = 0; 
	static int parpadeoActivoErrorReloj = 0;	
	if(parpadeoActivoErrorReloj==1){
		static int conteoMedioSegundo = 0;conteoMedioSegundo++;
		if(conteoMedioSegundo>=1){
			conteoMedioSegundo=0;
			ledEnRojo();
		}
	}else{
		conteo1minuto++;
		if(conteo1minuto>6){conteo1minuto=0; 	
			if(relojAnterior == reloj){	parpadeoActivoErrorReloj=1;DPRINTLN("Bateria Reloj agotada");  	}	
			relojAnterior = reloj;
		}			
	}
	reloj = Read_DS1307();
	pinVida();	
	menusOcultosCombinacionTeclas();
	modoForzado = EEPROM.read(4);
}

void proceso30segundos(void){	
	for(int i=0;i<numero_Slaves;i++){	vidaSlave[i] = '0';	}	
	impresion4();
	if(modoForzado==1){  EnvioRS485_modoForzado = 1;  }	
}

void proceso5minutos(void){
	//conteo20mn();
	enviarCorreoWCDescompuesto();
}

void proceso2minutos(void){	
	if(banderaActualizarHoraCuandoActualizoFecha){
		leerHoraServidor();
		banderaActualizarMemoriaDate=HIGH;
	}
}

void proceso1minuto(void){
	static int conteo = 0; conteo++;if(conteo>=4){conteo=0;proceso5minutos();}
	static int conteo2 = 0; conteo2++;if(conteo2>=1){conteo2=0;proceso2minutos();}	
	conteo20mn();
	if(inabilitarReset==1){  
		inabilitarReset=0;   
	}		
	if(banderaActualizarMemoriaDate){
		banderaActualizarMemoriaDate=LOW;		
		reloj = Read_DS1307();
	}
}



void proceso20minutos(void){
	leerHoraServidor();
}


void proceso1hora(void){
	static byte conteo2horas = 0;
	conteo2horas++;
	if(conteo2horas>=2){
		conteo2horas=0;
		if(FuncionamientoSinServidor == HIGH ){
			//Reset_AVR();
		}
	}	
}

void proceso6horas(void){
	leerHoraServidor();
}

void procesadorTiempo(void){
	static int conteo1segundo = 0;
	conteo1segundo++;
	if(conteo1segundo>=1000){
		conteo1segundo=0;
		proceso1segundos();
		static int conteo10segundos = 0;
		if(conteo10segundos>=10){    conteo10segundos=0;
			proceso10segundos();
			static long int conteo30segundos = 0;
			if(conteo30segundos>=2){    conteo30segundos=0;	//2 para 30 segundos
				static long int conteo1minuto = 0;
				if(conteo1minuto>=3){    conteo1minuto=0;	//3 para un minuto
					static int conteo20minutos = 0;
					conteo20minutos++;
					if(conteo20minutos>20){conteo20minutos=0; //20 para 20 minutos
						proceso20minutos();
						static byte conteo1hora = 0;
						conteo1hora++;
						if(conteo1hora>=3){
							conteo1hora = 0;
							proceso1hora();
							static int conteo6horas = 0;
							conteo6horas++;
							if(conteo6horas>=5){
								conteo6horas=0;
								proceso6horas();
							}
						}							
					}
					proceso1minuto();
					}else{
					proceso30segundos();
				}conteo1minuto++;
			}conteo30segundos++;
		}conteo10segundos++;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void enviarServidorWC1Activo_siEstaActivo(void){
	if(permisoEnviarWC==1){
		EnviarWebservlet(numero_Slaves+1, 2, URL, puerto, token, Method1, Method2, Method3, webService);//slave, codigo, URL, puerto
		permisoEnviarWC=0;
	}
}

void enviarServidorWC2Activo_siEstaActivo(void){
	if(permisoEnviarWC2==1){
		EnviarWebservlet(numero_Slaves+2, 2, URL, puerto, token, Method1, Method2, Method3, webService);//slave, codigo, URL, puerto
		permisoEnviarWC2=0;
	}
}

void enviarServidorRojoActivo(int esclavo){
	if (lamparaRoja[esclavo-1]!=1){
		EnviarWebservlet(esclavo, 2, URL, puerto, token, Method1, Method2, Method3, webService);//slave, codigo, URL, puerto
		lamparaRoja[esclavo-1]=1;
	}
}

void enviarServidorAzulActivo(int esclavo){
	if (lamparaAzul[esclavo-1]!=1){
		EnviarWebservlet(esclavo, 1, URL, puerto, token, Method1, Method2, Method3, webService);//slave, codigo, URL, puerto
		lamparaAzul[esclavo-1]=1;
	}
}

void enviarServidorBlancoActivo(int esclavo){
	if (lamparaBlanca[esclavo-1]!=1){
		EnviarWebservlet(esclavo, 4, URL, puerto, token, Method1, Method2, Method3, webService);//slave, codigo, URL, puerto
		lamparaBlanca[esclavo-1]=1;
	}
}

void enviarServidorVerdeActivo(int esclavo){
	if (lamparaVerde[esclavo-1]!=1){
		EnviarWebservlet(esclavo, 8, URL, puerto, token, Method1, Method2, Method3, webService);//slave, codigo, URL, puerto
		lamparaVerde[esclavo-1]=1;
	}
}

void enviarServidorGrisActivo(int esclavo, int grisaceo){
	if(grisaceo==1){
		if(WC1==1  ||  WC2==1){
			EnviarWebservlet(esclavo, 50, URL, puerto, token, Method1, Method2, Method3, webService);//slave, codigo, URL, puerto
		}else{
			EnviarWebservlet(esclavo, 17, URL, puerto, token, Method1, Method2, Method3, webService);//slave, codigo, URL, puerto
		}
// 		lamparaRoja[esclavo] = 0;
// 		lamparaVerde[esclavo] = 0;
// 		lamparaBlanca[esclavo] = 0;
// 		lamparaAzul[esclavo] = 0;
// 		pulsadoresSlave[esclavo] = 0;
	}
	WC1=0;
	WC2=0;
	
	lamparaAzul[esclavo-1]=0;
	lamparaRoja[esclavo-1]=0;
	lamparaBlanca[esclavo-1]=0;
	lamparaVerde[esclavo-1]=0;
	apagar[esclavo-1]=1;
	informado_sobre_WC1=1;
	informado_sobre_WC2=1;
}

void ledsComoSalidas(void){
	pinMode(LedRojo, OUTPUT);
	pinMode(LedAzul, OUTPUT);
	pinMode(LedVerde, OUTPUT);
	pinMode(LedBlanco, OUTPUT);
	if(EEPROM.read(7)==1){
		digitalWrite(LedAzul, HIGH);
		digitalWrite(LedBlanco, HIGH);
		digitalWrite(LedRojo, HIGH);
		digitalWrite(LedVerde, HIGH);
	}else{
		digitalWrite(LedAzul, LOW);
		digitalWrite(LedBlanco, LOW);
		digitalWrite(LedRojo, LOW);
		digitalWrite(LedVerde, LOW);
	}
	
}

void configuroParlante(void){
	pinMode(Zumbador, OUTPUT);
	pinMode(habilitadorZumbador, OUTPUT);
	digitalWrite(Zumbador, LOW);
}

void ledsMultipropositoComoSalidas(void){
	pinMode(Ledconexion, OUTPUT);
	pinMode(PinNoIP, OUTPUT);
	digitalWrite(Ledconexion, HIGH);
	digitalWrite(PinNoIP, HIGH);
}

void configuroMicroSD(void){
	pinMode(microSD, OUTPUT);
	digitalWrite(microSD, HIGH);//desabilito la microSD
}

void leerWC(void){
	if(WC1==0){
		int sensorValue = analogRead(WC_1);
		float voltage = sensorValue * (5.0 / 1023.0);
		static int memoriaWC1 = 0;
		if(voltage<1){ WC1=1; digitalWrite(LedRojo, HIGH);}
		if(voltage>4.2){WC1_descompuesto=1; }else{WC1_descompuesto=0; }
		if(memoriaWC1 != WC1){
			memoriaWC1=WC1;
			informado_sobre_WC1=1;
		}
	}
}



//**************************************************************************************************************************************************************************** 
void leerWC2(void){
	if(WC2==0){
		int sensorValue = analogRead(WC_2);
		float voltage = sensorValue * (5.0 / 1023.0);
		static int memoriaWC2 = 0;
		if(voltage < 1){ WC2=1; digitalWrite(LedRojo, HIGH);}
		if(voltage>4.2){WC2_descompuesto=1; }else{WC2_descompuesto=0; }
		if(memoriaWC2 != WC2){
			memoriaWC2=WC2;
			informado_sobre_WC2=1;
		}
	}  
}

void enviarRS485_WC_ON(void){
	enviar_RS485(char(ArribaWC),AdressSlave[numero_Slaves + 2],pinControlRS485);
	permisoEnviarWC=1;
}

void enviarRS485_WC_OFF(void){
	enviar_RS485(char(AbajoWC),AdressSlave[numero_Slaves + 1],pinControlRS485);
}

void enviarRS485_WC2_ON(void){
	enviar_RS485(char(ArribaWC),AdressSlave[numero_Slaves + 2],pinControlRS485);
	permisoEnviarWC2=1;
}

void enviarRS485_prenderRojo(int j){
	//si detecto que la lampara tiene encendido el rojo, pero el paciente correspondiente no tiene este codigo activo
	//le envio la orden de activar el rojo en este paciente
	impresion14(j);
	enviar_RS485(char(ArribaRojo),AdressSlave[j+1],pinControlRS485);
}

void enviarRS485_prenderBlanco(int j){
	//si detecto que la lampara tiene encendido el rojo, pero el paciente correspondiente no tiene este codigo activo
	//le envio la orden de activar el rojo en este paciente
	impresion14(j);
	enviar_RS485(char(ArribaBlanco),AdressSlave[j+1],pinControlRS485);
}

void enviarRS485_prenderVerde(int j){
	//si detecto que la lampara tiene encendido el rojo, pero el paciente correspondiente no tiene este codigo activo
	//le envio la orden de activar el rojo en este paciente
	impresion14(j);
	enviar_RS485(char(ArribaVerde),AdressSlave[j+1],pinControlRS485);
}

void enviarRS485_prenderAzul(int j){
	//si detecto que la lampara tiene encendido el rojo, pero el paciente correspondiente no tiene este codigo activo
	//le envio la orden de activar el rojo en este paciente
	impresion14(j);
	enviar_RS485(char(ArribaAzul),AdressSlave[j+1],pinControlRS485);
}

void informarCambiosWC1Pacientes(void){
	if(informado_sobre_WC1==1){ 
		if(WC1 == 1){      enviarRS485_WC_ON();          }
		if(WC1 == 0){	   enviarRS485_WC_OFF();         }
		informado_sobre_WC1=0;
		impresion5();		
	}
}

void informarCambiosWC2Pacientes(void){
	if(informado_sobre_WC2==1){ 
		if(WC2 == 1){           enviarRS485_WC2_ON();        }
		if(WC2 == 0){           enviarRS485_WC_OFF();       }
		informado_sobre_WC2=0;
		impresion6();		
	}
}

void blinkWCdescompuesto(void){
	byte Detector_led_rojo = 0;
	for(int i=0;i<numero_Slaves;i++){	if(lamparaRoja[i]==1){	Detector_led_rojo = 1;	i=numero_Slaves+5;	}		}
	if(Detector_led_rojo==0){
		static int conteoParpadeoWCdescompuesto = 0;
		if(conteoParpadeoWCdescompuesto>300){conteoParpadeoWCdescompuesto=0;}
		if(conteoParpadeoWCdescompuesto==0 || conteoParpadeoWCdescompuesto==2){digitalWrite(LedBlanco, HIGH);}
		else{if(LedBlanco==0){digitalWrite(LedBlanco, LOW);}}
		
		conteoParpadeoWCdescompuesto++;
	}
}

void blinkWC(void){
	static int estadoWC =0, conteoParpadeoWC = 0;
	if(WC1==1  ||  WC2==1){
		conteoParpadeoWC++;
		if(conteoParpadeoWC>=5){
			conteoParpadeoWC=0;
			if(estadoWC==0){estadoWC=1;digitalWrite(LedRojo, HIGH);}else{estadoWC=0;digitalWrite(LedRojo, LOW);}
		}
	}
}

void enciendoParpadeoWC_si_hayWCActivos(void){
	//si existe activacion de algun ba�o, enciendo el parpadeo del led rojo	
	if(WC1_descompuesto==1 || WC2_descompuesto==1){		
		blinkWCdescompuesto();						
	}else{
		blinkWC();		
	}
}

void mostrar_desconexion(void){
	static int numeroVeces = 2;
	if(  parpadeo_independiente == 1  ){
		static int EstadoParpadeoIndependiente = 0;
		static int RetardoParpadeoIndependiente = 0;
		static int ConteoParpadeoIndependiente = 0;
		RetardoParpadeoIndependiente++;
		if(RetardoParpadeoIndependiente>=numeroVeces){
			RetardoParpadeoIndependiente=0;
			if(EstadoParpadeoIndependiente==1){
				EstadoParpadeoIndependiente=0;
				digitalWrite(LedBlanco, LOW);//apaga
				}else{
				EstadoParpadeoIndependiente=1;
				digitalWrite(LedBlanco, HIGH); //prende
				ConteoParpadeoIndependiente++;
				if(ConteoParpadeoIndependiente>=numeroVeces){
					ConteoParpadeoIndependiente=0;
					parpadeo_independiente=0;
				}
			}
		}
	}
}

void enviarRS485_ApagarLeds(int selector){
	//envio la orden de apagar los leds, solo si en la recepcion anterior se detecta un gris pulsado
	enviar_RS485(char(ApagarLeds),AdressSlave[selector],pinControlRS485);
	apagar[selector-1]=0;
}

void enviarRS485_ApagarLeds_menosWC(int selector){
	//envio la orden de apagar los leds, solo si en la recepcion anterior se detecta un gris pulsado
	enviar_RS485(char(ApagarLeds_menosWC),AdressSlave[selector],pinControlRS485);
	apagar[selector-1]=0;
}

void enviarRS485_leerPulsadores(int selector){	
	//envio la orden de lectura de pulsadores, solo si en la recepcion anterior no se detecto un gris pulsado
	enviar_RS485(char(LeerPulsadores),AdressSlave[selector],pinControlRS485);
}

void enviarRS485_datoEthernet(int dato_enviar, char esclavo){
	enviar_RS485( char(  dato_enviar   )   , esclavo,pinControlRS485);
}

void prendoAzul_siHayAzul(void){
	for(int i=0;i<=numero_Slaves;i++){
		if(lamparaAzul[i]==1){ digitalWrite(LedAzul, HIGH);i=numero_Slaves+10;   }else{  digitalWrite(LedAzul, LOW);   }
	}
}

void prendoRojo_siHayRojo(void){
	for(int i=0;i<=numero_Slaves;i++){
		if(WC1!=1  &&  WC2!=1){
			if(lamparaRoja[i]==1){ digitalWrite(LedRojo, HIGH);i=numero_Slaves+10;   }else{  digitalWrite(LedRojo, LOW);   }
		}
	}
}

void prendoVerde_siHayVerde(void){
	for(int i=0;i<=numero_Slaves;i++){
		if(lamparaVerde[i]==1){ digitalWrite(LedVerde, HIGH);i=numero_Slaves+10;   }else{  digitalWrite(LedVerde, LOW);   }
	}
}

void prendoBlanco_siHayBlanco(void){
	for(int i=0;i<=numero_Slaves;i++){
		if(lamparaBlanca[i]==1){ digitalWrite(LedBlanco, HIGH);i=numero_Slaves+10;   }else{  digitalWrite(LedBlanco, LOW);   }
	}
}

void actualizarVariablesConMensajeRecibidoEthernet(String mensaje){
	static String temporal;
	temporal = mensaje.substring(0,1) ;
	char esclavo[2] = {'0','0'};
	temporal.toCharArray(esclavo,2);
	temporal = mensaje.substring(1,2) ;
	char codigo[2] = {'0','0'};
	temporal.toCharArray(codigo,2);	
	int slave = esclavo[0]-49;
	int codigoRecibidoINT = 0;
	
	//DPRINT("codigo:  ");DPRINTLN(   codigo   );
	//DPRINT("esclavo:  ");DPRINTLN(   slave  );
	int dato_enviar = 0;
	
	switch(codigo[0]){
		case '1':{ codigoRecibidoINT=1; dato_enviar = ArribaAzul;   lamparaAzul[    slave    ] = 1;	     	}break;
		case '2':{ codigoRecibidoINT=2;  dato_enviar = ArribaRojo;    lamparaRoja[    slave    ] = 1;		}break;
		case '4':{ codigoRecibidoINT=4;  dato_enviar = ArribaBlanco;  lamparaBlanca[    slave  ] = 1;		}break;
		case '8':{ codigoRecibidoINT=8;  dato_enviar = ArribaVerde;   lamparaVerde[    slave   ] = 1;		}break;
		case '0':{ codigoRecibidoINT=17;  dato_enviar = ApagarLeds;	 lamparaVerde[    slave   ] = 0;
			lamparaBlanca[    slave  ] = 0;
			lamparaRoja[    slave    ] = 0;
		lamparaAzul[    slave    ] = 0;		}break;
	}		
	
	
}

void detenerComunicacionServidor(void){
	client2.stop();
}

void verificacionComunicacionCorrecta(void){
	esperarRespuestaWebServlet=0;
	independiente = 0;
	detenerComunicacionServidor();
	impresion7();	
}


void ordenDirectaDelServidorParaIndependizarme(void){
	esperarRespuestaWebServlet=0;
	independiente = 1;
	detenerComunicacionServidor();
	impresion8();	
	sendTelegram("Servidor ordena independizarse");
}

void BusquedaErrorMensajeRecibido_ParaIndependizarElSistema(char c){
	if(c != 'N' && c!='\n' && c != '\r' && c!='0' && c!='1' && c!='2' && c!='3' && c!='4' && c!='5' && c!='6' && c!='7' && c!='8' && c!='9' && c!='#'){
		independiente = 1;    //me independizo por alguna falla con el servidor
		impresion9();	
		sendTelegram("Error Mensaje Recibido por el servidor, stma independiente");
	}
}



void conversion_binarios(int pulsadores,int esclavo){
	//obtengo el binario de los pulsadores actuales
	int pulsador = pulsadores;
	for(int i=0;i<5;i++){bits[i]=0;}
	int comparador = 16;
	for(int i=4;i>=0;i--){
		if(pulsador >= comparador){  bits[i] = 1;  pulsador=pulsador-comparador; }  else {  bits[i] = 0; }
		comparador = comparador / 2;
	}
	

	//obtengo el binario de los pulsadores pasados
	pulsador = pulsadoresSlave[esclavo-1];
	for(int i=0;i<5;i++){bits2[i]=0;}
	comparador = 16;
	for(int i=4;i>=0;i--){
		if(pulsador >= comparador){  bits2[i] = 1;  pulsador=pulsador-comparador; }  else {  bits2[i] = 0; }
		comparador = comparador / 2;
	}
}

void TraduscoInformacionRecibidaPacienteComoPacienteFuncionando(int esclavo ){
	//actualizo el estado de vida del paciente
	vidaSlave[esclavo - 1] = 'Y';
}

void AlmacenoEstadoPulsadoresDelPacienteEnUnaVariable(int esclavo , int pulsadores ){	
	pulsadoresSlave[esclavo-1]   = pulsadores;
}

void BuscoCambiosPulsadoresParaInformarServidorPacientesYLampara(int pulsadores,int esclavo){
	conversion_binarios(pulsadores , esclavo);
	//hallo los cambios de los pulsadores
	int grisaceo=0, verdusco=0,azulado=0,blancusco=0,rojiso=0;
	for(int i=4;i>=0;i--){
		if(  (bits[i] != bits2[i])    &&   (bits[i] ==1    )      ){
			switch(i){
				case 0:{   azulado=1;    }break;
				case 1:{   rojiso=1;     }break;
				case 2:{   blancusco=1;  }break;
				case 3:{   verdusco=1;   }break;
				case 4:{   grisaceo=1;   }break;
			}
		}
	}
	
	int datoPulsadoresVisibles = lamparaAzul[esclavo-1] + lamparaRoja[esclavo-1]*2 + lamparaBlanca[esclavo-1]*4 + lamparaVerde[esclavo-1]*8;
	int datoPulsadoresReales = bits[0] + bits[1]*2 + bits[2]*4 + bits[3]*8;
	if(datoPulsadoresVisibles != datoPulsadoresReales){
		for(int i=4;i>=0;i--){
			if( bits[i] ==1    ){
				DPRINT(bits[i]);
				switch(i){
					case 0:{   azulado=1;    }break;
					case 1:{   rojiso=1;     }break;
					case 2:{   blancusco=1;  }break;
					case 3:{   verdusco=1;   }break;
					case 4:{   grisaceo=1;   }break;
				}
			}
		}
	}	
	
	
	//informo sobre los cambios al servidor
	//actualizo los vectores de estado de color en la lampara y evito redundancia, haci no envio la misma info que reciba por ethernet	
	if(grisaceo==1 || pulsadores>=17){	enviarServidorGrisActivo(esclavo,grisaceo);				}
	if(azulado==1){		enviarServidorAzulActivo(esclavo);			}
	if(rojiso==1 || pulsadores==2){		enviarServidorRojoActivo(esclavo);	}
	if(blancusco==1){		enviarServidorBlancoActivo(esclavo);		}
	if(verdusco==1){	enviarServidorVerdeActivo(esclavo);				}
	impresion10(azulado,rojiso,blancusco,verdusco,grisaceo, esclavo);	
}

//**************************************************************************************************************************************************************************** 
int leeParametrosSD(int sel, int imprimir){
  int errorLectura = 0;
  parametrosSD.habilito_SD();
  delay(200);
  parametrosSD.Crear_DataBase(0,"");  
  
  puerto = parametrosSD.leoPuerto();  
  
  int memoriaPuerto = puerto;
  
  String URLstring = parametrosSD.leoURL();
    
  URLstring.toCharArray(URL,20);  
  webService = parametrosSD.leoWebService();
  Method1 = parametrosSD.leoMethod(1);
  Method2 = parametrosSD.leoMethod(2);
  Method3 = parametrosSD.leoMethod(3);
  numero_Slaves = parametrosSD.leoNumeroSlaves();
  numero_Slaves = int(numero_Slaves);
  if(sel==0){numero_Slaves=9;}
  number_WC = parametrosSD.leoNumeroWC();
  for(int i=5;i>=0;i--){
	  static int conteo=0;  
	  mac[conteo] =  parametrosSD.leoMAC(i+1); 
	  conteo++; 	  
  }
	


  parametrosSD.habilito_ethernet();

  puerto = memoriaPuerto;  
  if(puerto == 0 || webService == "" || Method1 == "" || Method2 == "" || Method3 == "" || numero_Slaves == 0 || number_WC == 0){
     errorLectura = 1;
	 sendTelegram("No se pudo leer la SD");
  }
  
  impresion11( imprimir );  
  return errorLectura;
}

void ProcesoModoForzado(void){
	EnvioRS485_modoForzado=0;
	static int conteo = 0;
	static int PanelPaciente = 1;
	switch(conteo){
		case 0:{
			DPRINT("Enciendo led verde en:");DPRINTLN(PanelPaciente);
			enviar_RS485(char(ArribaVerde),AdressSlave[PanelPaciente],pinControlRS485);
		}break;
		case 1:{
			DPRINT("Enciendo led blanco en:");DPRINTLN(PanelPaciente);
			enviar_RS485(char(ArribaBlanco),AdressSlave[PanelPaciente],pinControlRS485);
		}break;
		case 2:{
			DPRINT("Enciendo led rojos en:");DPRINTLN(PanelPaciente);
			enviar_RS485(char(ArribaRojo),AdressSlave[PanelPaciente],pinControlRS485);
		}break;
		case 3:{
			DPRINT("Enciendo led azul en:");DPRINTLN(PanelPaciente);
			enviar_RS485(char(ArribaAzul),AdressSlave[PanelPaciente],pinControlRS485);
		}break;
		case 4:{
			DPRINT("Apago los leds en el paciente: ");DPRINTLN(PanelPaciente);
			enviar_RS485(char(ArribaGris),AdressSlave[PanelPaciente],pinControlRS485);
		}break;
	}
	if(conteo>=4){
		conteo=-1;		
		if(PanelPaciente>=numero_Slaves){PanelPaciente=0;}	PanelPaciente++;
	}conteo++;
}

void apagar_Leds(int selector){
	if(WC1==0 && WC2==0){
		enviarRS485_ApagarLeds(selector);
	}else{
		enviarRS485_ApagarLeds_menosWC(selector);
	}
}

void ProcesoModoNormal(int selector){
	if(menuSecreto[0]==-1){
		menuSecreto[0]=0;
		enviar_RS485(char(ArribaWC),AdressSlave[numero_Slaves + 2],pinControlRS485);
		}else{
		if(apagar[selector-1]==1){
			apagar_Leds(selector);			
		}else{
			enviarRS485_leerPulsadores(selector);
		}
	}
}

void proceso_lectura_Apagado_RS485(void){
	static int selector = 0;
	static int retardoSlaves = 0;//necesario para lograr una comunicacion optima RS485
	
	//tengo dos opciones:
	//1-preguntar por el estado de los pulsadores en un slave
	//2-dar la orden de apagado a un slave
	//para elegir cual de las dos se va a ejecutar
	//se debe leer la recepcion anterior de dicho slave, si en la lectura anterior se detecto un gris pulsado, envio la orden2
	//si aun no se ha detectado un gris pulsado, ejecuto la orden1
	if(retardoSlaves>=FinretardoSlaves){
		retardoSlaves=0;
		if(selector>=numero_Slaves){selector=0;}
		selector++;
		impresion12(selector);
		if(EnvioRS485_modoForzado==1){
			ProcesoModoForzado();			
		} else{
			ProcesoModoNormal(selector);			
		}				
	}
	retardoSlaves++;
}

void procesoSecreto1(char c){
	//si el paciente envia una x o y, manipulo directamente el led rojo de la lampara
	if( c == 'x'){   digitalWrite(LedRojo, HIGH);   }
	if( c == 'y'){   digitalWrite(LedRojo, LOW);   }
}

void comprobarRecibidoDeSHIPP_enElPaciente(void){
	int bitsAlmacenados[5] = {0,0,0,0,0};   //azul - rojo - blanco - verde - gris
	int comparador;
	for(int j=0;j<numero_Slaves;j++){
		int pulsador = pulsadoresSlave[j];
		comparador = 16;		
		for(int i=4;i>=0;i--){
			if(pulsador >= comparador){  bitsAlmacenados[i] = 1;  pulsador=pulsador-comparador; }  else {  bitsAlmacenados[i] = 0; }
			comparador = comparador / 2;
		}
		if(bitsAlmacenados[1] != lamparaRoja[j] && lamparaRoja[j]==1      ){	
			static int contador = 0;
			static int contador2 = 0;
			contador++;
			if(contador<=20){
				enviarRS485_prenderRojo(j); 
			}else{
				contador2++;
				if(contador2>=10){
					contador2 = 0;
					contador = 0;
				}
			}				 
		}
		//if(bitsAlmacenados[0] != lamparaAzul[j] && lamparaAzul[j]==1      ){	enviarRS485_prenderAzul(j);   }
	}
}

void ActualizarSonido(void){
	//busco codigos sonoros activos y los hago sonar as�:
	//el rojo solo suena cuando el sistema este independiente
	//el azul suena siempre al igual que el WC
	
	int ONsonido = 0;
	int sonido_hab_rojo = 0;
	//detecto algun rojo activo
	for(int i=0;i<=numero_Slaves;i++){
		if(WC1!=1  &&  WC2!=1){		
			if(lamparaRoja[i]==1){  
				sonido_hab_rojo=1;		
				i=numero_Slaves+10;   
			}		
		}
	}
	
	//detecto algun WC activo
	int sonido_hab_WC = 0;	if(WC1==1  ||  WC2==1){	sonido_hab_WC=1;	ONsonido=1;		alarma=2;	}
	
	//detecto algun azul activo
	int sonido_hab_azul = 0;
	for(int i=0;i<=numero_Slaves;i++){
		if(lamparaAzul[i]==1){		sonido_hab_azul=1;		i=numero_Slaves+10;  ONsonido=1; alarma=1;}
	}
	
	//defino sonido segun independencia
	if(independiente==1 || iniciandoComoBasico==1){
		if(         sonido_hab_azul==1  ){
			alarma=1;	ONsonido=1;
			}else {
			if (   sonido_hab_WC==1    ){	alarma=2;	ONsonido=1;
				}else {
				if (   sonido_hab_rojo==1  ){	alarma=3;	ONsonido=1;
					}else {
					if(    sonido_hab_azul==1  ){		alarma=1;	ONsonido=1;
					}
				}
			}
		}
	}
	
	switch(sonido_manual){
		case 1:{       alarma=4;	ONsonido=1;    	}break;
		case 2:{       alarma=5;	ONsonido=1;    	}break;
	}
	
	if( EEPROM.read(4) == 0 ){  
		if(sonido_hab_rojo==3){
			ONsonido = 1;  //forzar que en el codigo rojo suene la lampara, esto para evitar que se silencie por un falso positivo
		}
		procesoSonido(alarma, ONsonido);	 
	}//envio la alarma a activar y el habilitador a la libreria sonido 
	else{  procesoSonido(alarma, 0);     }
}

void TiempoRetornoServidor(long int tiempo){
	static int conteo_espera_recibir = 0;
	if(esperarRespuestaWebServlet==1){
		conteo_espera_recibir++;
		if(conteo_espera_recibir >= tiempo){  //eficazmente probado con 10
			conteo_espera_recibir=0;
			esperarRespuestaWebServlet = 0;
			independiente = 1;    //me independizo por alguna falla con el servidor
			impresion13();
			guardoMicroSD(55,0); //el codigo 55 es para guardar la informacion que forzo la independencia
			cerrarComunServidor=1;
			sendTelegram("El servidor no responde a los datos enviados.");
		}
	}
	else{       conteo_espera_recibir=0;       }
}

void Led(String lucesita, byte estadoLed){
	if(  lucesita== "all"){
		if(listaErrores[0]==1){  digitalWrite(LedAzul, estadoLed);   }else{digitalWrite(LedAzul, LOW);  }
		if(listaErrores[1]==1){  digitalWrite(LedRojo, estadoLed);   }else{digitalWrite(LedRojo, LOW);  }
		if(listaErrores[2]==1){  digitalWrite(LedVerde, estadoLed);  }else{digitalWrite(LedVerde, LOW); }
		if(listaErrores[3]==1){  digitalWrite(LedBlanco, estadoLed); }else{digitalWrite(LedBlanco, LOW);}
	}
}

void rutinaMostrarError(int impresionInSetup){
	independiente = 1;    //me independizo por alguna falla con el servidor
	if(impresionInSetup==1){DPRINTLN("Fallo la configuracion SETUP..."); }
	digitalWrite(LedRojo, LOW);
	digitalWrite(LedAzul, LOW);
	digitalWrite(LedVerde, LOW);
	digitalWrite(LedBlanco, LOW);
	
	digitalWrite(LedAzul, HIGH);
	delay(200);
	digitalWrite(LedRojo, HIGH);
	delay(200);
	digitalWrite(LedVerde, HIGH);
	delay(200);
	digitalWrite(LedBlanco, HIGH);
	delay(200);
	digitalWrite(LedRojo, LOW);
	digitalWrite(LedAzul, LOW);
	digitalWrite(LedVerde, LOW);
	digitalWrite(LedBlanco, LOW);
	Led("all", HIGH);
	delay(200);
	Led("all", LOW);
	delay(200);
	Led("all", HIGH);
	delay(200);
	Led("all", LOW);
	delay(200);
	Led("all", HIGH);
	delay(200);
	Led("all", LOW);
	delay(200);
	Led("all", HIGH);
	alarma7_NURCALL();
	delay(1000);
	Led("all", LOW);
	delay(200);
}

int inicioBasico(void){
	int valor = 0;
	int sensorValue = analogRead(WC_1);
	float voltage = sensorValue * (5.0 / 1023.0);
	if(voltage < 1){
		valor = 1;
	}
	return valor;
}

void correccionIp_por_falloEnDHCP(int impresionInSetup){
	sendTelegram("Fallo con el DHCP");
	for(int i=0;i<=5;i++){DPRINT(mac[i],HEX);DPRINT(":"); }          DPRINTLN();
	if(impresionInSetup==1){DPRINTLN("Fallo la configuracion usando DHCP");  }
	FuncionamientoSinDHCP = HIGH;
	
	//en este bucle fallo la configuracion por DHCP, pero si previamente se habi obtenido IP esta se guardo en la EEPROM
	//los datos de la EEPROM se cargan en 	ip_1, asi que intento buscar IP usando estos valores precargados
	for(int i=0;i<3;i++){
		ledEnAmarillo(); delay(500);
		ledEnVacio();delay(500);
	}
	byte ip2[4] = { EEPROM.read(0), EEPROM.read(1) , EEPROM.read(2) , EEPROM.read(3)  };
	Ethernet.begin(mac,ip2);
	
	byte ip3[4];
	ip_1 = Ethernet.localIP();
	ip3[0]=ip_1[0];
	ip3[1]=ip_1[1];
	ip3[2]=ip_1[2];
	ip3[3]=ip_1[3];
	if(   ip2[0]!=ip3[0]  || ip2[1]!=ip3[1]   || ip2[2]!=ip3[2]   || ip2[3]!=ip3[3]   ){
		//en este punto fallo la IP por DCHP y fallo la memoria de la EEPROM, por lo cual el sistema funcionara permanentemente como independiente
		if(impresionInSetup==1){DPRINTLN("Fallo la configuracion usando EEPROM");  }
		for(int i=0;i<3;i++){
			ledEnRojo(); delay(500);
			ledEnVacio();delay(500);
		}
		Ethernet.begin(mac,ip);
		listaErrores[1]=1;
	}
}
