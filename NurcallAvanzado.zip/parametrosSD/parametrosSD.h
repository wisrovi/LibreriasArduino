
/*
Estas librerias, asi como el codigo de cada una, fueron creadas por 



William S. Rodriguez Villamizar - ingeniero Electronico UDI

La duracion de la creacion del codigo fue del 10MArzo2015 al 31Diciembre2015 

en labores de la FCV (www.FCV.org)



Gracias Dios Santisiomo por darme esta oportunidad, llenarme de bendiciones y darme las capacidades para lograr este proyecto en mi vida.

Le agradezco a mi familia por acompa�arme en todo el camino, educarme en todos los aspectos, aconsejarme y acompa�arme.

Le otorgo un agradecimiento especial al Ingeniero Miguel Angel Jurado Arenales - Ingeniero Electronico, quien vio en mi las capacidades, por las cuales me dio las primeras oportunidades para mostrar mis talentos, con lo cual, los inicios de mi carrera fueron gracias a �l.
*/


/*
  parametrosSD.h - Descripción de la librería
Creada por Nombre Autor, Fecha
Lanzado bajo licencia --- 
*/
#ifndef parametrosSD_h
#define parametrosSD_h
#include "arduino.h"
class parametrosSD {
  public:
   parametrosSD(int pinEthernet, int pinSD);
   void desabilito_ethernet();
   void desabilito_SD();
   void habilito_SD();
   void habilito_ethernet();
   int leoPuerto(void);
   int leoMAC(int sel);
   String leoMethod(int sel);
   String leoWebService(void);
   int leoNumeroWC(void);
   int leoNumeroSlaves(void);
   String leoURL(void);
   String leoDataBase(int bloque);
   void Crear_DataBase(int sel, String MACinterna);
   void Guardar_DataBase(String info);
   void Borrar_DataBase(void);
  private:  
   int bloque;
   String MACinterna;
   int _pinEthernet;
   int _pinSD;
   int puertoEthernet;
   int sel;
   int _sel;
   int MAC;
   String b;
   int NumeroWC;
   int NumeroSlaves;
   String info;
   int tam_lectura;
};
#endif
