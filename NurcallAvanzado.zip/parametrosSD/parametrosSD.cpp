
/*
Estas librerias, asi como el codigo de cada una, fueron creadas por 



William S. Rodriguez Villamizar - ingeniero Electronico UDI

La duracion de la creacion del codigo fue del 10MArzo2015 al 31Diciembre2015 

en labores de la FCV (www.FCV.org)



Gracias Dios Santisiomo por darme esta oportunidad, llenarme de bendiciones y darme las capacidades para lograr este proyecto en mi vida.

Le agradezco a mi familia por acompa�arme en todo el camino, educarme en todos los aspectos, aconsejarme y acompa�arme.

Le otorgo un agradecimiento especial al Ingeniero Miguel Angel Jurado Arenales - Ingeniero Electronico, quien vio en mi las capacidades, por las cuales me dio las primeras oportunidades para mostrar mis talentos, con lo cual, los inicios de mi carrera fueron gracias a �l.
*/


/*
parametrosSD.cpp -Descripción cpp
Creada por Nombre Autor, Fecha
Lanzado bajo licencia---
*/

//#define DEBUG   //If you comment this line, the DPRINT & DPRINTLN lines are defined as blank.
#ifdef DEBUG    //Macros are usually in all capital letters.
  #define DPRINT(...)    Serial.print(__VA_ARGS__)     //DPRINT is a macro, debug print
  #define DPRINTLN(...)  Serial.println(__VA_ARGS__)   //DPRINTLN is a macro, debug print with new line
#else
  #define DPRINT(...)     //now defines a blank line
  #define DPRINTLN(...)   //now defines a blank line
#endif




#include "arduino.h"
#include "parametrosSD.h"

#include <SPI.h>
#include <SD.h>

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
File myPuerto;
#define SDpuerto() SD.open("PARAME~1/PUERTO.TXT")

File myMAC;
#define SD_MAC6() SD.open("PARAME~2/MAC6.txt")
#define SD_MAC5() SD.open("PARAME~2/MAC5.txt")
#define SD_MAC4() SD.open("PARAME~2/MAC4.txt")
#define SD_MAC3() SD.open("PARAME~1/MAC3.txt")
#define SD_MAC2() SD.open("PARAME~1/MAC2.txt")
#define SD_MAC1() SD.open("PARAME~1/MAC1.txt")

File myURL;
#define SD_URL() SD.open("PARAME~1/URL.txt")

File myWebService;
#define SD_WebService() SD.open("PARAME~1/WEBSER~1.txt")

File myNumeroSlaves;
#define SD_NumeroSlaves() SD.open("PARAME~2/NUMERO~1.txt")

File myNumeroWC;
#define SD_NumeroWC() SD.open("PARAME~2/NUMEROWC.txt")

File myMethod;
#define SD_Method1() SD.open("PARAME~1/METHOD1.txt")
#define SD_Method2() SD.open("PARAME~1/METHOD2.txt")
#define SD_Method3() SD.open("PARAME~1/METHOD3.txt")
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

File myDataBase;
#define leo_DataBase() SD.open("ALMACEN/Data.txt")
#define Grabo_DataBase() SD.open("ALMACEN/Data.txt", FILE_WRITE); 
String localDataBase = "ALMACEN/Data.txt";




parametrosSD::parametrosSD(int pinEthernet, int pinSD)
{
  pinMode(pinEthernet,OUTPUT); 
  pinMode(pinSD,OUTPUT);  
  _pinEthernet = pinEthernet;
  _pinSD = pinSD;
}

void parametrosSD::desabilito_ethernet()
{
  digitalWrite(_pinEthernet, HIGH); 
}

void parametrosSD::desabilito_SD()
{
  digitalWrite(_pinSD, HIGH); 
}


void parametrosSD::habilito_SD()
{  
  digitalWrite(_pinEthernet, HIGH);    
  digitalWrite(_pinSD, LOW);  
  if (!SD.begin(_pinSD)) {  DPRINTLN("[habilito_SD] - error");   return;   } 
}

void parametrosSD::habilito_ethernet()
{  
  digitalWrite(_pinSD, HIGH);    
  digitalWrite(_pinEthernet, LOW);  
}

//aca se usan las variables:
//int puertoEthernet
int parametrosSD::leoPuerto()
{
  int puertoEthernet=0;
  myPuerto = SDpuerto();
  if (myPuerto) {    
    while (myPuerto.available()) {
       puertoEthernet = puertoEthernet + int(myPuerto.read()-48) *1000 ;
       puertoEthernet = puertoEthernet + int(myPuerto.read()-48) *100 ;
       puertoEthernet = puertoEthernet + int(myPuerto.read()-48) *10 ;
       puertoEthernet = puertoEthernet + int(myPuerto.read()-48) *1 ;  
    }
    myPuerto.close();
  } else {DPRINTLN("error en el archivo: puerto.txt");    }
  return puertoEthernet;
}

//aca se usan las variables:
//internas:
//int MAC
//publicas:
//int sel
int parametrosSD::leoMAC(int sel){
  int MAC =0;
  switch(sel){
      case 6:{
           myMAC = SD_MAC6() ;
      }break;
      case 5:{
           myMAC = SD_MAC5() ;
      }break;
      case 4:{
           myMAC = SD_MAC4() ;
      }break;
      case 3:{
           myMAC = SD_MAC3() ;
      }break;
      case 2:{
           myMAC = SD_MAC2() ;
      }break;
      case 1:{
           myMAC = SD_MAC1() ;
      }break;
  }
    
  if (myMAC) {
      while (myMAC.available()) {
          MAC = MAC + int(myMAC.read()-48) *100 ;
          MAC = MAC + int(myMAC.read()-48) *10 ;
          MAC = MAC + int(myMAC.read()-48) *1 ;      
     }
     myMAC.close();
  } else {   
      switch(sel){
          case 6:{
              DPRINTLN("error en el archivo: MAC6.txt");
          }break;
          case 5:{
              DPRINTLN("error en el archivo: MAC5.txt");
          }break;
          case 4:{
              DPRINTLN("error en el archivo: MAC4.txt");
          }break;
          case 3:{
              DPRINTLN("error en el archivo: MAC3.txt");
          }break;
          case 2:{
              DPRINTLN("error en el archivo: MAC2.txt");
          }break;
          case 1:{
              DPRINTLN("error en el archivo: MAC1.txt");
          }break;
      }  
  }
  return MAC;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//aca se usan las variables:
//privadas:
//String b
//publicas:
//int sel
String parametrosSD::leoMethod(int sel){
  String b;
  switch(sel){
      case 1:{
          myMethod = SD_Method1() ;
      }break;
      case 2:{
          myMethod = SD_Method2() ;
      }break;
      case 3:{
          myMethod = SD_Method3() ;
      }break;
  } 
  if (myMethod) {    
    while (myMethod.available()) {
       b.concat(   char(  myMethod.read()  )  );       
    }
    myMethod.close();
  } else {   
      switch(sel){
        case 1:{
            DPRINTLN("error en el archivo: Method1.txt"); 
        }break;
        case 2:{
            DPRINTLN("error en el archivo: Method2.txt");
        }break;
        case 3:{
            DPRINTLN("error en el archivo: Method3.txt");
        }break;
      }        
  }
  return b;
}

//aca se usan las variables:
//String b
String parametrosSD::leoWebService(void){
  String b;
  myWebService = SD_WebService() ;  
  if (myWebService) {    
    while (myWebService.available()) {
       b.concat(   char(  myWebService.read()  )  );       
    }
    myWebService.close();
  } else {   DPRINTLN("error en el archivo: URL.txt");    }
  return b;
}

//aca se usan las variables:
//int NumeroSlaves
int parametrosSD::leoNumeroSlaves(void){
  int NumeroSlaves=0;
  myNumeroSlaves = SD_NumeroSlaves() ;  
  if (myNumeroSlaves) {    
    while (myNumeroSlaves.available()) {
       NumeroSlaves = NumeroSlaves + int(myNumeroSlaves.read()-48)*10; 
       NumeroSlaves = NumeroSlaves + int(myNumeroSlaves.read()-48)*1;     
    }
    myNumeroSlaves.close();
  } else {   DPRINTLN("error en el archivo: NumeroSlaves.txt");    }
  return NumeroSlaves;
}

//aca se usan las variables:
//int NumeroWC
int parametrosSD::leoNumeroWC(void)
{
  int NumeroWC=0;
  myNumeroWC = SD_NumeroWC() ;  
  if (myNumeroWC) {    
    while (myNumeroWC.available()) {
       NumeroWC = NumeroWC + int(myNumeroWC.read()-48)*10 ;
       NumeroWC = NumeroWC + int(myNumeroWC.read()-48)*1 ;     
    }
    myNumeroWC.close();
  } else {   DPRINTLN("error en el archivo: NumeroWC.txt");    }
  return NumeroWC;
}

//aca se usan las variables:
//String b
String parametrosSD::leoURL(void)
{
  String b;
  myURL = SD_URL() ;  
  if (myURL) {    
    while (myURL.available()) {
       b.concat(   char(  myURL.read()  )  );       
    }
    myURL.close();
  } else {   DPRINTLN("error en el archivo: URL.txt");    }
  return b;
}

String parametrosSD::leoDataBase(int bloque)
{
	  String b = "";
	  myDataBase = leo_DataBase() ;
	  if (myDataBase) {
		  int conteo_caracteres = 0;
		  while (myDataBase.available()) {
			  conteo_caracteres++;
			  char data = char(  myDataBase.read()  ) ;
			  if(   (conteo_caracteres <= (bloque+1)*668)     &&  (conteo_caracteres>=bloque*668)    ){
				  if(conteo_caracteres == (bloque+1)*668){
					  b.concat(  "\n..."  );break;					  
				   }else{					   
						b.concat(  data  );							
						if(bloque==0 && conteo_caracteres<40 && data=='\n'){	b = "";  }																		  				  
				   }
			  }
		  }
		  myDataBase.close();
		  } else {   DPRINTLN("error en el archivo: Data.txt");    }
		  return b;
}

void parametrosSD::Crear_DataBase(int sel, String MACinterna){
     if (!SD.exists(localDataBase)) {
          myDataBase = Grabo_DataBase();
          if (myDataBase) {
			  if(sel==1){    myDataBase.print(MACinterna);        }
               else{	     myDataBase.print("   \n");           }
          }
          myDataBase.close();
          delay(2000);
     }     
}

void parametrosSD::Guardar_DataBase(String info){
     myDataBase = Grabo_DataBase();  
     if (myDataBase) {          
          myDataBase.print(info); 
          myDataBase.close();          
     }else {   DPRINTLN("error en el archivo: Data.txt");    }
     
}

void parametrosSD::Borrar_DataBase(void){
     if (SD.exists("ALMACEN/Data.txt")) {
         SD.remove("ALMACEN/Data.txt");         
     }
}


