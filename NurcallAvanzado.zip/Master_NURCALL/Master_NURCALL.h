
/*
Estas librerias, asi como el codigo de cada una, fueron creadas por 



William S. Rodriguez Villamizar - ingeniero Electronico UDI

La duracion de la creacion del codigo fue del 10MArzo2015 al 31Diciembre2015 

en labores de la FCV (www.FCV.org)



Gracias Dios Santisiomo por darme esta oportunidad, llenarme de bendiciones y darme las capacidades para lograr este proyecto en mi vida.

Le agradezco a mi familia por acompa�arme en todo el camino, educarme en todos los aspectos, aconsejarme y acompa�arme.

Le otorgo un agradecimiento especial al Ingeniero Miguel Angel Jurado Arenales - Ingeniero Electronico, quien vio en mi las capacidades, por las cuales me dio las primeras oportunidades para mostrar mis talentos, con lo cual, los inicios de mi carrera fueron gracias a �l.
*/

//#define DEBUG   //If you comment this line, the DPRINT & DPRINTLN lines are defined as blank.
#ifdef DEBUG    //Macros are usually in all capital letters.
  #define DPRINT(...)    Serial.print(__VA_ARGS__)     //DPRINT is a macro, debug print
  #define DPRINTLN(...)  Serial.println(__VA_ARGS__)   //DPRINTLN is a macro, debug print with new line
#else
  #define DPRINT(...)     //now defines a blank line
  #define DPRINTLN(...)   //now defines a blank line
#endif







#include <avr/wdt.h>
#define Reset_AVR() wdt_enable(WDTO_1S); while(1) {}


//libreria EEPROM
#include <EEPROM.h>
//posiciones usadas en la memoria EEPROM:
//0,1,2,3 = IP
//4 = bandera de modo forzado
//5 =  WC control
//6 = modo basico
//7 = reinicio con muestreo de errores
//8 = prueba reinicios cuando el servidor no da ping


//incluyo la libreria para la definicion de todas las variables globales usadas en el codigo
#include <variables.h>

//incluyo la libreria que hace funcionar el reloj RTC
#include<RTC_DS1307.h>

//incluyo la libreria para la comunicacion especifica RS485 con los pacientes
#include <RS485Master.h>

//incluyo la libreria para la comunicacion especifica de NURCALL con la microSD
#include <parametrosSD.h>
parametrosSD parametrosSD(10,4);//pin_ethernet, pin_SD

//incluyo la libreria para las impresiones
#include <impresiones.h>



//incluyo la libreria para la comunicacion y funcionamiento del ETHERNET
#include <EthernetMaster.h>

//incluyo la libreria para el control del sonido
#include "pitches.h"
#include <SonidoMaster.h>

//incluyo la libreria para los procesos generales que suceden al compilar las anteriores librerias
#include <TraductorFunciones.h>

//incluyo la libreria para los procesos generales que suceden al compilar las anteriores librerias
#include <UtilidadesCodigo.h>

//incluyo la libreria para el control de las interrupciones asi como el proceso que sucede en cada interrupcion
#include <interrupcion.h>

//libreria para el perro guardian
#include <avr/wdt.h> 


/*
 * codigo_principal    codigo_principal    codigo_principal    codigo_principal    codigo_principal    codigo_principal    
 * codigo_principal    codigo_principal    codigo_principal    codigo_principal    codigo_principal    codigo_principal    
 * codigo_principal    codigo_principal    codigo_principal    codigo_principal    codigo_principal    codigo_principal    
 * codigo_principal    codigo_principal    codigo_principal    codigo_principal    codigo_principal    codigo_principal    
 */

void pruebaLedBicolor(void){
	ledEnVerde();
	delay(300);
	ledEnAmarillo();
	delay(300);
	ledEnRojo();
	delay(300);
}

void MASTER_NURCALL_SETUP(int refrescar, int impresion_general, int independencia, int impresionMicroSD, int reinicioLamp, int impresionInSetup){   
	wdt_disable();//desactivo el perro guardian
	EEPROM.update(5, 0);  //habilito la lectura del WC
	Serial.begin(9600); 
	configurarChipSonido();
	refrescarPagina = refrescar;
	reinicioLampara = reinicioLamp;
    if(impresionInSetup==1){DPRINTLN("sistema iniciado....");}    
    imprimir = impresion_general;
    configurarLampara();
    independiente = independencia;
	
	if(EEPROM.read(7)==1){alarma6_NURCALL();}
	
	pruebaLedBicolor();
	
	if(iniciandoComoBasico == 0){	
		iniciandoComoBasico = inicioBasico();	
		if(iniciandoComoBasico==1){
			if(EEPROM.read(6)==1){
				EEPROM.update(6, 0);
			}else{
				EEPROM.update(6, 1);
			}
		}	
		iniciandoComoBasico = EEPROM.read(6); 			
	}
	
	// leo microSD
	if(leeParametrosSD(1,impresionMicroSD) == 0)//lectura_microSD(1-completa/0-parcial), imprimir(1-si/0-no)
	{ digitalWrite(LedAzul, LOW); }  else {listaErrores[0]=1;}	
	if(numero_Slaves <= 0 || numero_Slaves >10){listaErrores[0]=1;}	
		
	if(iniciandoComoBasico == 1){    
		Serial.println("Inicio como basico");
		if(EEPROM.read(7)==1){alarma7_NURCALL();   }
		digitalWrite(LedRojo, LOW);
		digitalWrite(LedAzul, LOW);
		digitalWrite(LedVerde, LOW);
		digitalWrite(LedBlanco, LOW);	
	}
	else{
		delay(500);
		
		
		
		//busco IP
		static int IPrespaldo = 0;
				
		if (Ethernet.begin(mac) == 0) {
			correccionIp_por_falloEnDHCP(impresionInSetup);
			sendTelegram("Fallo obtencionIP DHCP");
		}else{
			byte ip2[4];
			ip = Ethernet.localIP();
			ip2[0]=ip[0];
			ip2[1]=ip[1];
			ip2[2]=ip[2];
			ip2[3]=ip[3];
			EEPROM.update(0, ip2[0]);
			EEPROM.update(1, ip2[1]);
			EEPROM.update(2, ip2[2]);
			EEPROM.update(3, ip2[3]);
		}
		
		if(impresionInSetup==1){
			Serial.print("mi IP: ");
			Serial.print(EEPROM.read(0));Serial.print(".");
			Serial.print(EEPROM.read(1));Serial.print(".");
			Serial.print(EEPROM.read(2));Serial.print(".");
			Serial.println(EEPROM.read(3));
			sendTelegram("Sistema iniciado");
		}
		int obtencionIP = ip;
		if(listaErrores[1]==0){     digitalWrite(LedRojo, LOW);    }
		//inicio servidor
		server.begin();
		
		//me registro en webservlet
		token = registrar(URL,puerto,mac[0],mac[1],mac[2],mac[3],mac[4],mac[5],webService,numero_Slaves,number_WC, Method1, Method2);
		if(token.length() == 8){
			digitalWrite(LedVerde, LOW);
			if(impresionInSetup==1){
				DPRINT("token: ");  DPRINTLN(token);
			}  independiente = 0;
		} else{
			if(impresionInSetup==1){DPRINTLN("[0 - setup] sistema independiente... "); }
			listaErrores[2]=1;
			independiente = 1;
			sendTelegram("Se recibio token invalido");
		}
	}	
	    
    configurarRS485(pinControlRS485);
    delay(300);
    enviar_RS485(char(ResetPaciente),AdressSlave[0],pinControlRS485);DPRINTLN("paneles de paciente reiniciados.");
	delay(1000);
	
	if(iniciandoComoBasico == 0){   
		if( listaErrores[0]==1 || listaErrores[1]==1 || listaErrores[2]==1){    if(EEPROM.read(7)==1){rutinaMostrarError(impresionInSetup);}     }
		delay(500);
	}    	
    
	if(EEPROM.read(7)==1){alarma5_NURCALL();}
	configure_RTCDS1307();
	reloj = Read_DS1307();
	if(FuncionamientoSinServidor==HIGH){
		for(int i=0;i<3;i++){
			ledEnVerde(); delay(500);
			ledEnVacio();delay(500);
		}
		ledEnAmarillo();
	}
    configurar_interrupcion(numero_Slaves);//envio el numero de Slaves para que configure la comunicacion a un valor optimo segun el NumSlaves        
    digitalWrite(LedBlanco, LOW);  
	modoForzado = EEPROM.read(4);
	if( modoForzado == 1 ){DPRINTLN("Sistema en modo Forzado (no emitira sonido)"); }	
		
    if(impresionInSetup==1){DPRINTLN("inicio terminado...");}       
	wdt_enable(WDTO_8S);//wdt_enable(WDTO_8S);//configuro el perro guardian para que reinicie el sistema si pasan xx segundos sin que el sistema responda 
	EEPROM.update(7, 0); //cierro el muestreo del reinicio seguro
	
	ArduinoOTA.begin(Ethernet.localIP(), "NURCALL", "NURCALL", InternalStorage);
	Serial.println("Sistema iniciado.");
}

void MASTER_NURCALL_LOOP(int imprimirWerServlet, int imprimirRS485, int imprimirHTTP){
	configurarRS485(pinControlRS485);
	static int intercambiador = 0;
	if(EEPROM.read(6)==0){ 
	   if(intercambiador==0){
		   intercambiador=1;
		   procesarEthernet(   recibirWebservlet(imprimirWerServlet)   );         //imprimir(1-si / 0-no)
		}else{
		   intercambiador=0;
		   procesarRTAWerServlet(        lecturaHTTP(imprimirHTTP)         )  ; //1 imprimo datos - 0 no imprimo datos
	   }
	}
		
	procesarRS485(      recibidoRS485(imprimirRS485)        );  //imprimir(1-si / 0-no)   
	OtrosProcesosDeTiempo();
	wdt_reset();
	ArduinoOTA.poll();
}

