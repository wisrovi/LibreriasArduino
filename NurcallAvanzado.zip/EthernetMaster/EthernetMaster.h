
/*
Estas librerias, asi como el codigo de cada una, fueron creadas por 



William S. Rodriguez Villamizar - ingeniero Electronico UDI

La duracion de la creacion del codigo fue del 10MArzo2015 al 31Diciembre2015 

en labores de la FCV (www.FCV.org)



Gracias Dios Santisiomo por darme esta oportunidad, llenarme de bendiciones y darme las capacidades para lograr este proyecto en mi vida.

Le agradezco a mi familia por acompa�arme en todo el camino, educarme en todos los aspectos, aconsejarme y acompa�arme.

Le otorgo un agradecimiento especial al Ingeniero Miguel Angel Jurado Arenales - Ingeniero Electronico, quien vio en mi las capacidades, por las cuales me dio las primeras oportunidades para mostrar mis talentos, con lo cual, los inicios de mi carrera fueron gracias a �l.
*/




/*
 * ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet 
 * ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet 
 * ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet 
 * ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet 
 * ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet 
 * ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet 
 * ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet 
 * ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet 
 * ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet ethernet 
 */




#include <SPI.h>
#include <Ethernet.h>
#include <ArduinoOTA.h>

IPAddress ip(192, 168, 1, 177);
IPAddress ip_1(255, 255, 255, 1);
EthernetServer server(80);// me establezco a mi mismo como un servidor para recibir clientes
EthernetClient client2; //establezco al sistema para acceder como cliente a un servidor





//**************************************************************************************************************************************************************************** 

/*
 * de aqui en adelante se debe construir una libreria llamada webservlet
 * esta libreia contiene las funciones:
 * 
 * 1) char lecturaHTTP(int sel);//donde sel=1, retorna todo valor que llegue por el wervidor, si es cero(0) no retorna impresion
 * 
 * 2) void EnviarWebservlet(int slave, int codigo, char address[],int port, String tokensito, String m1, String m2, String m3)
 *                                                     URL         puerto      token        metodo1    metodo2    metodo3 
 *              con esta funcion envio datos al webservlet para que almacene en la base de datos                                       
 *              
 * 3) String registrar(char address[],int port, int MAC1, int MAC2, int MAC3, int MAC4, int MAC5, int MAC6, String webservlet, int N_Slaves, int N_WC, String m1, String m2);             
 *                        URL        puerto    MAC[0]   MAC[1]     MAC[2]    MAC[3]    MAC[4]    MAC[5]      webservlet        N_slaves       N WC   metodo1     metodo2                                                        
 *             con esta funcion me registro en el servidor y me retorna el token                     
 *             
 * 4) String recibirWebservlet(int sel);
 *
 *me retorna toda la informacion que llegue filtrada, asi:           
 *si mi IP es:172.16.66.91, cargo esta URL: http://172.16.66.91/nurcall?S-0& esta funcion me retornara S0
 *pero si cargo http://172.16.66.91/nurcall?5-2& esta funcion me retornara 52
 *esto con el fin de que el sistema pueda mostrar estos datos para depurar
 * 
 * 
 */

//**************************************************************************************************************************************************************************** 


#include <Base64.h>
EthernetClient telegramCliente;
//maximo se puede recibir 100 caracteres en texto ASCII
void sendTelegram(String fail) {	
  if(fail.length()>80){
    fail = fail.substring(0, 80);
	//DPRINTLN("Recortando datos, pues la cadena a enviar es muy larga");
  }
  
  String ip = String(EEPROM.read(0));
  ip = ip + "." + String(EEPROM.read(1));
  ip = ip + "." + String(EEPROM.read(2));
  ip = ip + "." + String(EEPROM.read(3));

  String mensajeEnviar = "La lampara con ip: ";
  mensajeEnviar.concat(ip);
  mensajeEnviar.concat(" -> ");
  mensajeEnviar.concat(fail);
  
  char input[mensajeEnviar.length()+1];
  mensajeEnviar.toCharArray(input, mensajeEnviar.length()+1);
    
  int inputLen = sizeof(input);
  int encodedLen = base64_enc_len(inputLen);
  char encoded[encodedLen];
  base64_encode(encoded, input, inputLen); 
  String datosConvertidosBase64 = String(encoded);    
  datosConvertidosBase64.replace("=", "");
      
  int len = telegramCliente.available();
  if (len > 0) {
    byte buffer[80];
    if (len > 80) len = 80;
    telegramCliente.read(buffer, len);
    Serial.write(buffer, len);
  }
  
  //DPRINT("Intentando enviar mensaje por Telegram");
  if (telegramCliente.connect("172.30.19.88", 1991)) {  
    String url = "GET /telegram?ID_GROUP=-383161081&MENSAJE=";		
	url.concat(datosConvertidosBase64);
	url.concat(" HTTP/1.1");	
	DPRINT("urlSend: ");
    DPRINTLN(url);
        
    char urlSend[url.length()+1];
    url.toCharArray(urlSend, url.length()+1);    
    
    telegramCliente.println(urlSend);
    telegramCliente.println("Host: www.fcv.org");
    telegramCliente.println("Connection: close");
    telegramCliente.println();
	
	DPRINT("connected to ");
    DPRINTLN(telegramCliente.remoteIP());
  } else {
    // if you didn't get a connection to the server:
    //DPRINTLN("connection failed");
  }  
}






String registrar(char address[],int port, int MAC1, int MAC2, int MAC3, int MAC4, int MAC5, int MAC6, String webservlet, int N_Slaves, int N_WC, String m1, String m2){
  MAC_address[0] = MAC1;
  MAC_address[1] = MAC2;
  MAC_address[2] = MAC3;
  MAC_address[3] = MAC4;
  MAC_address[4] = MAC5;
  MAC_address[5] = MAC6;

	
  ////////////////////////////////////////////////////////////////////////////////
  banderaUsoEthernet = HIGH;
  client2.stop();
  if (client2.connect(address, port)) {
    ///////////////////////  organizo la trama de datos para realizar la primera comunicacion con el webservlet   ////////////////////////
    String tramaGET = "GET /";
    tramaGET.concat(webservlet);
    tramaGET.concat(m1);tramaGET.concat(32);
    tramaGET.concat(m2);tramaGET.concat(    (      (N_Slaves+N_WC)*100 + N_WC         )     );
    String StrMac; for(int i=0;i<6;i++){   StrMac.concat(MAC_address[i]);StrMac.concat(":");   }      
    tramaGET.concat("&mac=");tramaGET.concat(StrMac);        
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////    
    client2.println(     tramaGET            );  //envio la trama inicial, tambien llamada matricula con el webservlet

        //establezco unos datos de remitente para el webservlet
    client2.println("Host: www.nurcall.fcv.org");
    client2.println("User-Agent: WISROVI001");
    client2.println("Connection: close");
    client2.println();
  } else{
	  DPRINTLN("fallo la matricula");FuncionamientoSinServidor = HIGH;
  } 
  ////////////////////////////////////////////////////////////////////////////////
  banderaUsoEthernet = LOW;
  delay(12); 
  if (imprimirEnviadoWebServlet==1)  {
	  DPRINT("Enviado_WebServlet: ");DPRINT("32-");DPRINT(    (N_Slaves+N_WC)*100 + N_WC    );DPRINTLN();
  }
  

      //para confirmar que la comunicacion fue exitosa, webservlet me retorna una cadena alfanumerica de 8 caracteres aleatoria, llamada token
      /////////////////////   con esta rutina recepciono este token ///////////////////////////////////////////////////////////////////////////
  String tokensito = "";    
  byte estabandera = 0;  
  for(int i=0;i<500;i++){
      delay(5);
	  wdt_reset();
      if (client2.available()) {
          char j = client2.read(); 
          if( int(j)>32 && int(j)<126){            
             if(estabandera==1){  tokensito.concat(String(j));  }
             if(j == 'Y'){estabandera=1;}          
          }        
      }   
  } ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if(tokensito.length() != 8){
        DPRINTLN("[registrar] - error(0) -  falla en la obtencion del token");DPRINTLN();
        tokensito="";
  }
  return tokensito;
}

boolean isValidNumber(String str){
	boolean respuesta = false;
	for(byte i=0;i<str.length();i++)
	{
		if(isDigit(str.charAt(i))) {
			respuesta = true;
		}else{
			respuesta = false;
			i=str.length() + 10;
		}
	}
	return respuesta;
}

void memorizarMSG(char c){
	static int tamanoVector = 9;
	static char memoriaRecibido[] = {'0','T', '2', 'T', '4', 'T', '6', 'T', '8', 'T', '0','T', '2', 'T', '4'};
		
	for(int i=1;i<tamanoVector;i++){	memoriaRecibido[i-1] = memoriaRecibido[i];	}	memoriaRecibido[tamanoVector-1] = c;
	acumuladoMsgServidor = "";	for(int i=0;i<tamanoVector;i++){	acumuladoMsgServidor.concat(memoriaRecibido[i]);	}
	
	//rutina para guardar la fecha dada por el servidor	
	if(acumuladoMsgServidor.substring(1,2)=="#" && !banderaActualizarHoraCuandoActualizoFecha){
		String temporal = acumuladoMsgServidor.substring(2, acumuladoMsgServidor.length()-1);
		temporal.concat(reloj.substring(8,10));
		temporal.concat(reloj.substring(11,13));
		temporal.concat(reloj.substring(14,16));
		temporal.concat(reloj.substring(17,19));
		actualizarRTC(temporal);
		banderaActualizarHoraCuandoActualizoFecha = HIGH;
		reloj = Read_DS1307();
		DPRINTLN("actualizando FECHA en RTC: " + temporal);
	}
	
	if(isValidNumber(acumuladoMsgServidor.substring(0, 8)) && c=='T' ){
		String temporal = reloj.substring(0,4);//a�o
		temporal.concat(reloj.substring(5,7));//mes
		temporal.concat(acumuladoMsgServidor.substring(0,2));//dia
		temporal.concat(acumuladoMsgServidor.substring(2,4));//hora
		temporal.concat(acumuladoMsgServidor.substring(4,6));//minuto
		temporal.concat(acumuladoMsgServidor.substring(6,8));//segundo
		DPRINTLN("actualizando HORA en RTC : " + temporal);
		actualizarRTC(temporal);
		banderaActualizarHoraCuandoActualizoFecha= LOW;		
		reloj = Read_DS1307();
	}
	
	//rutina para guardar el dia, minuto, segundos en el RTC 
	if(c!='0' && c!='1' && c!='2' && c!='3' && c!='4' && c!='5' && c!='6' && c!='7' && c!='8' && c!='9' || c=='Y'){
		DPRINT("Respuesta_Webservlet aca: ");   DPRINTLN(c);		
		int conteoT = 0; 	for(int i=0;i<tamanoVector;i++){   	if(acumuladoMsgServidor.substring(i, i+1) == "T"){   conteoT++;   }   	}
		/*if(conteoT==1 && c=='T'){
			horaServidor = acumuladoMsgServidor.substring(0, acumuladoMsgServidor.length()-1);
			String temporal = reloj.substring(0,4);
			temporal.concat(reloj.substring(5,7));
			temporal.concat(horaServidor);		
			DPRINTLN("entro aca");	
			if (!temporal.indexOf("#")) {
				DPRINTLN("actualizando hora en RTC");
				actualizarRTC(temporal);
				banderaActualizarHoraCuandoActualizoFecha= LOW;
			}
		}*/
	}		
}

//horaServidor
char lecturaHTTP(int sel){
  char c = 'N';  
  if (client2.available()) {
    c = client2.read();
    if(sel==1){      
		if(c != 'N' && c!='\n' && c != '\r' ){
			 memorizarMSG(c);					
		}		   
	}      
  }  
  return c;
}

void guardoMicroSD(int slave, int codigo){
	if((slave != 34 && slave!=33 && slave!=35 && slave<36) || slave==55){
			String tramaGET = "";
			//en este bucle el sistema grabara en la microSD todo suceso que ocurra dentro de la independencia
			parametrosSD.habilito_SD();
			parpadeo_independiente=1;
			tramaGET.concat(slave);tramaGET.concat(",");
			switch(codigo){
				case 17:{  tramaGET.concat('F');           }break;
				case 50:{  tramaGET.concat('W');           }break;
				case 16:{  tramaGET.concat('W');           }break;
				default:{  tramaGET.concat(codigo);        }break;
			}
			tramaGET.concat(",");	
			if(independiente!=1){
				tramaGET.concat( reloj );
			}else{
				if(WC1==1  ||  WC2==1){
					if(slave!=(numero_Slaves+1)  &&  slave!=(numero_Slaves+2)){
						tramaGET.concat( reloj );
					}else{
						tramaGET.concat( reloj);
					}
				}else{
					tramaGET.concat( reloj );
				}
			}
	
			if(codigo != 0){
				DPRINT(tramaGET);
			}
	
	
			delay(50);
			String tramaGET2 = tramaGET;
	
			if(slave!=55){
				if(codigo==1 || codigo==2 || codigo==4 || codigo==8 || codigo==17 || codigo==50 || codigo==16){
					parametrosSD.Guardar_DataBase(tramaGET2);
				}
			}else{
				if(ultima_info[0]!=0  && ultima_info[1]!=0){
					tramaGET = "";
					tramaGET.concat(ultima_info[0]);tramaGET.concat(",");
					switch(ultima_info[1]){
						case 17:{	  tramaGET.concat('F');	  }break;
						case 50:{	  tramaGET.concat('W');	  }break;
						case 16:{	  tramaGET.concat('W');	  }break;
						default:{	  tramaGET.concat(ultima_info[1]);}break;
					}	  tramaGET.concat(","); tramaGET.concat( ultimaHora );
					if(ultima_info[1]==1 || ultima_info[1]==2 || ultima_info[1]==4 || ultima_info[1]==8 || ultima_info[1]==17 || ultima_info[1]==50 || ultima_info[1]==16){
						parametrosSD.Guardar_DataBase(tramaGET);
					}
				}
			}
	
			parametrosSD.habilito_ethernet();
			ultima_info[0]=0;
			ultima_info[1]=0;
	}else{
		DPRINT("error en restriccion de datos al grabar en microSD: ");DPRINT(slave);DPRINT(codigo);
	}
}

String mensajeCodigo33(void){
	String msgEnviado = "";
	for(int i=0;i<numero_Slaves;i++){
		int temporal = lamparaVerde[i]*8 + lamparaBlanca[i]*4 + lamparaRoja[i]*2 + lamparaAzul[i];
		switch(temporal){
			case 15:{	msgEnviado.concat("F");			}break;
			case 14:{	msgEnviado.concat("E");			}break;
			case 13:{	msgEnviado.concat("D");			}break;
			case 12:{	msgEnviado.concat("C");			}break;
			case 11:{	msgEnviado.concat("B");			}break;
			case 10:{	msgEnviado.concat("A");			}break;
			default:{
				msgEnviado.concat(temporal);
			}break;
		}
	} if(WC1==1){	msgEnviado.concat("2"); } else{  msgEnviado.concat("0");  }
	return msgEnviado;
}

String mensajeServidor(int slave, int codigo, char address[],int port, String tokensito, String m1, String m2, String m3, String webservlet){
	String tramaGET = "GET /";
	String msgEnviado = "";
	tramaGET.concat(webservlet);
	tramaGET.concat(m1);tramaGET.concat(slave);
	tramaGET.concat(m2);
	switch(codigo){
		case 17:{	   tramaGET.concat('F');   msgEnviado = "F";		  }break;
		case 50:{	   tramaGET.concat('W');   msgEnviado = "W";		  }break;
		case 16:{	   tramaGET.concat('W');   msgEnviado = "W";		  }break;
		default:{
			if(slave==33){
				msgEnviado=mensajeCodigo33();
				tramaGET.concat(msgEnviado);
			}else{
				tramaGET.concat(codigo);
				msgEnviado = String(char(codigo + 48));
			}
		}break;
	}
	tramaGET.concat(m3);tramaGET.concat(tokensito);
	//////////////////////////////////////////////////////////////////////
	
	client2.println(        tramaGET          );
	client2.println("Host: www.nurcall.fcv.org");
	client2.println("User-Agent: WISROVI001");
	client2.println("Connection: close");
	client2.println();
	
	return msgEnviado;
}

void chequeoClaves(int codigo){
	String clave = "";
	for(int i=0;i<6;i++){    memoriaLlamados[i]=memoriaLlamados[i+1];  }   memoriaLlamados[5] = codigo;
	
	for(int i=0;i<6;i++){
		switch(memoriaLlamados[i]){
			case 8:{  clave.concat('v');	}break;   //verde
			case 4:{  clave.concat('b');	}break;   //blanco
			case 1:{  clave.concat('a');	}break;   //azul
			case 2:{  clave.concat('r');	}break;   //rojo
			case 17:{  clave.concat('g');	}break;   //gris
		}		
	}	
		
	if(clave=="rbvgbg"){
		menuSecreto[0]=1;menuSecreto[1]=1;
		DPRINT("clave recibida: ");DPRINTLN(menuSecreto[1]);
	}
	if(clave=="rbvgrg"){
		menuSecreto[0]=1;menuSecreto[1]=2;
		DPRINT("clave recibida: ");DPRINTLN(menuSecreto[1]);
	}	
	if(clave=="rvbgbg"){
		if(EEPROM.read(6)==1){
			EEPROM.update(6, 0);
		}else{
			EEPROM.update(6, 1);
		}
		
		DPRINT("modo basico:  ");DPRINT(EEPROM.read(6));
	}
}


//**************************************************************************************************************************************************************************** 
//int slave
//int codigo
//char address[]
//int port
//String tokensito
//String tramaGET
void EnviarWebservlet(int slave, int codigo, char address[],int port, String tokensito, String m1, String m2, String m3, String webservlet) {  
	wdt_reset();
	if(iniciandoComoBasico==0 && FuncionamientoSinServidor==LOW){ 
		if(independiente==0  || slave==33){	
			client2.stop();
			String tramaGET = "";		  
			String msgEnviado = "";
			if(slave==33 || slave==34 || slave<10 || slave==35){
				if(slave != 33){  ultima_info[0]=slave;  ultima_info[1]=codigo;	  ultimaHora = reloj;	  }
				esperarRespuestaWebServlet=1;
				if (client2.connect(address, port)) {   	msgEnviado = mensajeServidor(slave,codigo,address,port,tokensito,m1,m2,m3,webservlet);	   }
				if(imprimirEnviadoWebServlet==1){   DPRINT("Enviado_WebServlet: ");DPRINT(slave);DPRINT(msgEnviado);DPRINTLN();   }
			}else{
				DPRINT("error de datos: ");DPRINT(slave);DPRINT(codigo);
			}			           
		} else{
			//en este bucle el sistema grabara en la microSD todo suceso que ocurra dentro de la independencia
			guardoMicroSD(slave,codigo);
		}		 
	}else{
		//en este bucle el sistema grabara en la microSD todo suceso que ocurra dentro del modo basico
		guardoMicroSD(slave,codigo);
	}	
	chequeoClaves(codigo);	
}



String admin(void){
	String b;
	b ="\nMonitoreo interno como administrador:\n\n";	
	b.concat("token: ");
	if(FuncionamientoSinServidor == HIGH ){b.concat(" Hubo un problema con el servidor, para corregir el problema debe REINICIAR la lampara...");}
	else{if(token==""){b.concat("no adquirido");}else{b.concat(token);}}
	b.concat("\n\n");															  //k
	b.concat("-------------------------------------------------------------------------");b.concat("- | green | white | red | blue |\n");
	for(int i=0;i<numero_Slaves;i++){
		b.concat("paciente ");b.concat(i+1);b.concat(": ");
		switch(vidaSlave[i]){
			case '0':{
				b.concat("No se encuentra comunicacion-RS485 con este Slave.          ");
			}break;
			case 'Y':{
				b.concat("Comunicacion RS485 con este Slave funcionando correctamente.");
				b.concat(" - ");b.concat("|   ");b.concat(lamparaVerde[i]);
				b.concat("   |   ");b.concat(lamparaBlanca[i]);
				b.concat("   |  ");b.concat(lamparaRoja[i]);
				b.concat("  |  ");b.concat(lamparaAzul[i]);
				b.concat("   |");
			}break;
		}
		b.concat("\n");
	}
	b.concat("WC = "); if(WC1==1 || WC2==1){b.concat(" ON");}else{b.concat(" OFF");}
	b.concat("\n--------------------------------------------------------------------------------------------------------");
	b.concat("\n      (Paquetes Enviados: ");b.concat(conteoLecturasEnviadosRS485);
	
	b.concat(")     (Tiempo Trabajo continuo: ");
	float tiempoTrabajo = millis()/1000;
	if( (tiempoTrabajo/60) > 59 ){
		b.concat(tiempoTrabajo/3600);b.concat(" Horas");
	}else{
		b.concat(tiempoTrabajo/60);b.concat(" Minutos");
	}
	b.concat(")\n");
	
	long int porcentaje = conteoLecturasCorrectasRS485*100 / conteoLecturasEnviadosRS485;
	b.concat("  (Lecturas Correctas: ");b.concat(porcentaje);b.concat("%)");
	porcentaje = (   conteoLecturasEnviadosRS485-(conteoLecturasCorrectasRS485+conteoRuidoRS485)   ) *100 / conteoLecturasEnviadosRS485;
	b.concat("  (Paquetes Perdidos: ");b.concat(porcentaje);b.concat("%)");
	porcentaje = conteoRuidoRS485*100 / conteoLecturasEnviadosRS485;
	b.concat("  (Ruidos encontrados: ");b.concat(porcentaje);b.concat("%) \n");
	
	b.concat("\nsistema = "	);
	if(independiente == 1){   b.concat(" independiente ");}else{b.concat(" normal ");}
	if(modoForzado==1){b.concat("- forzado \n");}	else{b.concat(" \n");}
	b.concat("\n__________________________\n \nconsultado: ");b.concat(reloj);
	b.concat("__________________________\n \n Version Elementos: \n");
	b.concat("Version Software Lampara: ");
	b.concat(versionLampara);
	b.concat(" - Version Hardware Lampara: 4.2 \n");
	b.concat("Version Software Panel Paciente: 0.31 - Version Hardware Panel Paciente: 4.0 \n");
	b.concat("-- Dia 17 Febrero 2020 --\n__________________________\n ");
	b.concat("Autor de la idea: WISROVI,\nHardware Dise�ado y creado por Giovanni Manotas y William Rodriguez");
	b.concat("\nFirmware Disenado y creado por Steve Villamizar\n");
	b.concat("\n\nTodo se lo debo a mi padre Dios, gracias Dios por tus bendiciones...");
	return b;
}


//**************************************************************************************************************************************************************************** 
//int sel
//String info
//static byte banderaDataGet
//static byte bandera_lectura_get
//boolean FlagTexBlank
//char c
//char inf1
//char inf2
String recibirWebservlet(int sel){
	imprimirEnviadoWebServlet = sel;
	EthernetClient client = server.available();
	String info = "void";
	if (client) { 
		String almacen;
		static byte banderaDataGet = 0;
		static byte bandera_lectura_get = 0;
		boolean FlagTexBlank = true;    
		char c, inf1, inf2;
    
		while (client.connected()) {
			if (client.available()) {
			c = client.read();  
			//if(sel==1){DPRINT(c);       }
			almacen.concat(String(c));
			if(almacen == "GET /nurcall"){bandera_lectura_get=1;    }
			if(bandera_lectura_get==1){    
					switch(c){
						case '?':{  banderaDataGet=1;    }break;
						case '-':{  banderaDataGet=2;    }break;
						case '&':{  banderaDataGet=3;    }break;
						default:{
							if(banderaDataGet==1){  inf1=c;   }
							if(banderaDataGet==2){  inf2=c;   }
						}break;
					}
			}    
        
			if (c == '\n' && FlagTexBlank) {
				client.println("HTTP/1.1 200 OK");
				client.println("Content-Type: text/plain");
				client.println("Connection: close");
				if(refrescarPagina==1){
					client.println("Refresh: 5");//esta linea se puede eliminar si se desea
				}
				client.println();
				//client.println("<!DOCTYPE HTML>");//esta line ase puede eliminar si se desea
				//client.println("<html>");//esta line ase puede eliminar si se desea
				//mensaje a agregar/////////////////    
				if(inf1=='A' && inf2=='D'){
					String b = admin();							        
					client.println(b);
				}
				else {
					int imprimirMAC = 0;
					String b; 			  
					if(inf2=='M'){
						int pagina = inf1 - '0';
						if(pagina<0 || pagina>9){	pagina = 0;	}
						parametrosSD.habilito_SD();
						delay(50);
						String SD_read = parametrosSD.leoDataBase(pagina) ;
						b.concat(  SD_read   );
						parametrosSD.habilito_ethernet();   
					} else{
						if(inf1=='E' && inf2=='A'){
								b.concat("usted esta borrando la microSD");
								parametrosSD.Borrar_DataBase();  
								String b="MAC:";
								for(int i=0;i<6;i++){   b.concat(mac[i]);b.concat(":");   }  b.concat("\n");
								parametrosSD.Guardar_DataBase(b);
								b.concat("\nborrada: ");b.concat(reloj);   
								sendTelegram("Borrando la microSD");
						}else{ 
							if((inf1=='R' && inf2=='A') || (inf1=='M' && inf2=='T')  ){
								if(inabilitarReset==0){	
									b.concat("usted esta reiniciando la lampara...");	
									b.concat("\nreiniciada: ");
									if(inf1=='M' && inf2=='T'){
										b.concat("\nreinicio por mantenimiento: ");
										EEPROM.update(7, 1); //abro el muestreo del reinicio seguro
									}			
									sendTelegram("Reiniciando lampara.");
								}else{  
									b.concat("Antes de poder reiniciar la lampara debe esperar 3 minutos desde el ultimo reinicio..."); 
									b.concat("\nRespuesta Automatica en: ");  
								}							
								b.concat(reloj); 
								client.println(b);
								client.stop();
								if(reinicioLampara == 1 && inabilitarReset==0){
									inabilitarReset = 1;
									enviar_RS485(char(ResetPaciente),AdressSlave[0],pinControlRS485);
									Reset_AVR();
								}
							}else{
								if(inf1=='L' && inf2=='P'){
									if(FuncionamientoSinServidor==LOW){
										long int dato = (conteoLecturasEnviadosRS485 / 8) *7;
										long int error = conteoLecturasEnviadosRS485 - (conteoLecturasCorrectasRS485+0,1*conteoLecturasCorrectasRS485+conteoRuidoRS485);
										if(error > dato){b = "N";}else{b = "Y";}
										for(int i=0;i<numero_Slaves;i++){b.concat(",");	if(vidaSlave[i]=='Y'){	b.concat('A');	}else{	b.concat('D');	}	}
										temporalPinVidaServidor = 1;	
										independiente = 0;
									}else{
										//El sistema encontro un problema grave y necesita recibir la orden de reinicio para responder a este item
										b = "No se encontro servidor se requiere reinicio dispositivo...";
										b.concat("\nleido: ");b.concat(reloj);
									}
								}else{			
									if(inf1=='F' && inf2=='T'){
										b.concat("Foced test ON");	b.concat("\nOrden asignada en: ");b.concat(reloj);
										EEPROM.update(4, 1);
										modoForzado = EEPROM.read(4);
									}else{
										if(inf1=='S' && inf2=='T'){
											b.concat("Foced test OFF");	b.concat("\nOrden asignada en: ");b.concat(reloj);
											EEPROM.update(4, 0);
											modoForzado = EEPROM.read(4);
										}else{
											if(inf1=='I' && inf2=='N'){
												b.concat("sistema independiente...");
												independiente = 1;
											}else{
												if(inf1=='W' && inf2=='C'){												
													static int WC_deshabilitado = 0;
													if(WC_deshabilitado == 0){
														WC_deshabilitado = 1;
														b.concat("WC deshabilitado... ");
														EEPROM.update(5, 1);  //deshabilito la lectura del WC
													}else{
														WC_deshabilitado = 0;
														b.concat("WC dhabilitado... ");
														EEPROM.update(5, 0);  //habilito la lectura del WC
													}	
													b.concat("\nejecutado: ");b.concat(reloj);											
												}else{
													b.concat("usted desplego el mensaje: ");
													b.concat(inf1);b.concat(inf2);
													b.concat("\nleido: ");b.concat(reloj);													
												}											
											}										
										}
									}
								}
							}
						}
					}  
					client.println(b);				
				}
				/////////////////////////////////////
				break;
			}
			if (c == '\n') {  FlagTexBlank = true;  almacen="";  bandera_lectura_get=0;  banderaDataGet=0;   }
			else if (c != '\r') { FlagTexBlank = false;  }
			}
		}  
		info="";info.concat(String(inf1));info.concat(String(inf2));  
		if(info.length()!=2){info="";}
		delay(1);
		client.stop();
		//DPRINTLN();DPRINT("datos: ");DPRINTLN(info);
		}
		if(sel==1){
			if(info != "void" && info != ""){		  
				DPRINT("Recibido_ethernet: ");DPRINTLN(info);
			}
		}
  
  return info;
}


