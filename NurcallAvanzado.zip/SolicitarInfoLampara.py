Nurcall = {
    "536" : "172.30.131.48"
}

ip = Nurcall["536"]


import requests
s = requests.Session()
html = s.get('http://' + Nurcall["536"] + '/nurcall?A-D&').text

lineas = str(html).split('\n')

fechaHora = str()
tiempoTrabajoContinuo = str()
paquetesPerdidos  = str()
modoFuncionamiento =str()
versionFirwareLampara = str()

for line in lineas:
    indiceFecha = line.find("consultado:") + 11
    if indiceFecha >= 11:    
        fechaHora = line[indiceFecha:]  
        
    indiceTrabajoContinuo = line.find("Tiempo Trabajo continuo:") +24
    if indiceTrabajoContinuo >= 24:
        tiempoTrabajoContinuo = line[indiceTrabajoContinuo:-1]
        
    indicePaquetesPerdidos = line.find("Paquetes Perdidos:") +18
    if indicePaquetesPerdidos >= 18:
        paquetesPerdidos = line[indicePaquetesPerdidos:indicePaquetesPerdidos+3]
        
    indiceModoFuncionamiento = line.find("sistema = ") + 10
    if indiceModoFuncionamiento >= 10:
        modoFuncionamiento = line[indiceModoFuncionamiento:]
        
    indiceVersionFirmware = line.find("Version Software Lampara: ") + 26
    if indiceVersionFirmware >= 26:
        versionFirwareLampara = line[indiceVersionFirmware:indiceVersionFirmware+5]
            
           
print()
print("****************" + " Lampara " + ip + " ****************")
print("Modo Funcionamiento:", modoFuncionamiento)
print("Version Firware Lampara:", versionFirwareLampara)
print("Fecha Hora:", fechaHora)
print("Tiempo Trabajo continuo:", tiempoTrabajoContinuo)
print("Paquetes Perdidos:", paquetesPerdidos)
