
/*
Estas librerias, asi como el codigo de cada una, fueron creadas por 



William S. Rodriguez Villamizar - ingeniero Electronico UDI

La duracion de la creacion del codigo fue del 10MArzo2015 al 31Diciembre2015 

en labores de la FCV (www.FCV.org)



Gracias Dios Santisimo por darme esta oportunidad, llenarme de bendiciones y darme las capacidades para lograr este proyecto en mi vida.

Le agradezco a mi familia por acompa�arme en todo el camino, educarme en todos los aspectos, aconsejarme y acompa�arme.

Le otorgo un agradecimiento especial al Ingeniero Miguel Angel Jurado Arenales - Ingeniero Electronico, quien vio en mi las capacidades, por las cuales me dio las primeras oportunidades para mostrar mis talentos, con lo cual, los inicios de mi carrera fueron gracias a �l.
*/


/*
 * interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion 
 * interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion 
 * interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion 
 * interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion 
 * interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion 
 * interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion 
 * interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion 
 * interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion 
 * interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion 
 * interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion interrupcion 
 */


#include <TimerOne.h>
  #define tiempoInterrupcion 10000   //  100000 

#include <TimerThree.h>
#define tiempoInterrupcion2 100000   //  100000 

//**************************************************************************************************************************************************************************** 
void interrupcion1(){	
	static int contadorPara100milisegundos = 0;
	contadorPara100milisegundos++;
	
	if(contadorPara100milisegundos>=10){		
		ProcesosWC(1,0);
		comprobarRecibidoDeSHIPP_enElPaciente();
		proceso_lectura_Apagado_RS485();
	}
	
	if(contadorPara100milisegundos>=8){
		ActualizarSonido(); 
	}	
	
	if(contadorPara100milisegundos>=10){
		contadorPara100milisegundos=0;
		TiempoRetornoServidor(17);  //recomendado 10		
		parpadeoTodoEstaBien();
		//mostrar_desconexion();
	}	   
}


void interrupcion3(){
	static byte conteo = 0;conteo++;
	if(conteo>=10*2){
		conteo=0;	
	}
	if( banderaUsoEthernet == HIGH ){
		wdt_reset();
		DPRINTLN("-");
	}	
}


//**************************************************************************************************************************************************************************** 
void configurar_interrupcion(int CantidadSlaves){
  Timer1.initialize(tiempoInterrupcion); 
  Timer1.attachInterrupt( interrupcion1 );  
  
  Timer3.initialize(tiempoInterrupcion2);         // initialize timer3, and set a 1/2 second period
  Timer3.attachInterrupt( interrupcion3 );
  
  
  
  
  if(CantidadSlaves<3){ FinretardoSlaves=3;  }   //recomendado 3
  if(CantidadSlaves>6){ FinretardoSlaves=1;  }
  if(CantidadSlaves==1){ FinretardoSlaves=5;  }   
}


