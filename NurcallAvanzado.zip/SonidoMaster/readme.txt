1----------------------------------      50

static int melody[] = {
          NOTE_C6,NOTE_A5,NOTE_FS5,NOTE_D5,NOTE_A4,NOTE_E4,NOTE_A3,NOTE_A2,NOTE_A1            
      };
      static int noteDurations[] = {
        4, 4, 4, 3, 2, 4, 3, 1, 4
      };

      static int silenceDurations[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 4
      };




2--------------------------------------------------------