
/*
Estas librerias, asi como el codigo de cada una, fueron creadas por 



William S. Rodriguez Villamizar - ingeniero Electronico UDI

La duracion de la creacion del codigo fue del 10MArzo2015 al 31Diciembre2015 

en labores de la FCV (www.FCV.org)



Gracias Dios Santisiomo por darme esta oportunidad, llenarme de bendiciones y darme las capacidades para lograr este proyecto en mi vida.

Le agradezco a mi familia por acompa�arme en todo el camino, educarme en todos los aspectos, aconsejarme y acompa�arme.

Le otorgo un agradecimiento especial al Ingeniero Miguel Angel Jurado Arenales - Ingeniero Electronico, quien vio en mi las capacidades, por las cuales me dio las primeras oportunidades para mostrar mis talentos, con lo cual, los inicios de mi carrera fueron gracias a �l.
*/





void configurarChipSonido(void){
	if(ChipSonido==0){
		ONalarmasonora = LOW;
		OFFalarmasonora = HIGH;
	}else{
		ONalarmasonora = HIGH;
		OFFalarmasonora = LOW;
	}
}



//sonido codigo azul
/*
static int numero_notas_total = 8;
static int melody[] = {
	NOTE_C6,NOTE_D8,NOTE_C6,NOTE_D8,NOTE_C6,NOTE_D8,NOTE_C6,NOTE_D8
};
static int noteDurations[] = {
	7, 4, 7, 4, 7, 4, 7, 4
};

static int silenceDurations[] = {
	0, 1, 0, 1, 0, 1, 0, 1
};

*/
void alarma1_NURCALL(void){//codigo azul
      static int numero_notas_total = 8;
      static int melody[] = {
	      NOTE_B7,NOTE_A7,NOTE_B7,NOTE_A7,NOTE_B7,NOTE_A7,NOTE_B7,NOTE_A7
      };
      static int noteDurations[] = {
	      7, 4, 7, 4, 7, 4, 7, 4
      };

      static int silenceDurations[] = {
	      0, 1, 0, 1, 0, 1, 0, 1
      };
	  
      
      
	  
	  //no modificar de aca en adelante
      static int notaMusical = 0;
      static int conteoTiempos = 0;
      static String estado = "sonido";
      int Duracion = noteDurations[notaMusical];
      int silencio = silenceDurations[notaMusical];

       if(estado == "sonido"){
              if(Duracion >= conteoTiempos){
                  static int unavez = 0;
                  if(unavez==0){
                       unavez=1;tone(Zumbador, melody[notaMusical], Duracion*100); 
                  }                                                
                  conteoTiempos++;
                  if(Duracion == conteoTiempos){
                      conteoTiempos=0;
                      estado = "silencio";
                      unavez=0;
                  }
              }
      }     
      if(estado == "silencio"){
          if(silencio >= conteoTiempos){
              if(silencio == conteoTiempos){
                  conteoTiempos=0;                  
                  estado = "sonido";
                  notaMusical++;
                  if(notaMusical>=numero_notas_total){notaMusical=0;}
              }else{
                  noTone(Zumbador);
                  conteoTiempos++;
              }   
          }
      }    
}

//sonido llamada de ba�o
/*
static int numero_notas_total = 8;
static int melody[] = {
	NOTE_E5,NOTE_D8,NOTE_C6,NOTE_E5,NOTE_D8,NOTE_C6,NOTE_E5,NOTE_D8
};
static int noteDurations[] = {
	6, 6, 6, 6, 6, 6, 6, 6
};

static int silenceDurations[] = {
	30, 30, 30, 30, 30, 30, 30, 30
};


static int numero_notas_total = 8;
static int melody[] = {
	NOTE_C6,NOTE_C8,NOTE_C6,NOTE_C8,NOTE_C6,NOTE_C8,NOTE_C6,NOTE_C8
};
static int noteDurations[] = {
	6, 6, 6, 6, 6, 6, 6, 6
};

static int silenceDurations[] = {
	30, 30, 30, 30, 30, 30, 30, 30
};
*/


void alarma2_NURCALL(void){//codigo WC   
	 static int numero_notas_total = 8;
	 static int melody[] = {
		 NOTE_D5,NOTE_F6,NOTE_D5,NOTE_F6,NOTE_D5,NOTE_F6,NOTE_D5,NOTE_F6
	 };
	 static int noteDurations[] = {
		 20, 6, 20, 6, 20, 6, 20, 6
	 };

	 static int silenceDurations[] = {
		 2, 30, 2, 30, 2, 30, 2, 30
	 };
	 
	 //no modificar de aca en adelante
     static int notaMusical = 0;
     static int conteoTiempos = 0;
     static String estado = "sonido";
     int Duracion = noteDurations[notaMusical];
     int silencio = silenceDurations[notaMusical];

     if(estado == "sonido"){
	     if(Duracion >= conteoTiempos){
		     static int unavez = 0;
		     if(unavez==0){
			     unavez=1;tone(Zumbador, melody[notaMusical], Duracion*100);
		     }
		     conteoTiempos++;
		     if(Duracion == conteoTiempos){
			     conteoTiempos=0;
			     estado = "silencio";
			     unavez=0;
		     }
	     }
     }
     if(estado == "silencio"){
	     if(silencio >= conteoTiempos){
		     if(silencio == conteoTiempos){
			     conteoTiempos=0;
			     estado = "sonido";
			     notaMusical++;
			     if(notaMusical>=numero_notas_total){notaMusical=0;}
			     }else{
			     noTone(Zumbador);
			     conteoTiempos++;
		     }
	     }
     }
}

//codigo rojo como independiente
/* tradicional
static int numero_notas_total = 8;
static int melody[] = {
	NOTE_C6,NOTE_C8,NOTE_C6,NOTE_C8,NOTE_C6,NOTE_C8,NOTE_C6,NOTE_C8
};
static int noteDurations[] = {
	6, 6, 6, 6, 6, 6, 6, 6
};

static int silenceDurations[] = {
	30, 30, 30, 30, 30, 30, 30, 30
};
*/

/* propuesta
static int numero_notas_total = 8;
static int melody[] = {
	NOTE_E5,NOTE_F6,NOTE_E5,NOTE_F6,NOTE_E5,NOTE_F6,NOTE_E5,NOTE_F6
};
static int noteDurations[] = {
	20, 6, 20, 6, 20, 6, 20, 6
};

static int silenceDurations[] = {
	2, 30, 2, 30, 2, 30, 2, 30
};
*/
void alarma3_NURCALL(void){//codigo rojo
     static int numero_notas_total = 8;
     static int melody[] = {
	     NOTE_C6,NOTE_C8,NOTE_C6,NOTE_C8,NOTE_C6,NOTE_C8,NOTE_C6,NOTE_C8
     };
     static int noteDurations[] = {
	     6, 6, 6, 6, 6, 6, 6, 6
     };

     static int silenceDurations[] = {
	     30, 30, 30, 30, 30, 30, 30, 30
     };
     
	 
	 //no modificar de aca en adelante
     static int notaMusical = 0;
     static int conteoTiempos = 0;
     static String estado = "sonido";
     int Duracion = noteDurations[notaMusical];
     int silencio = silenceDurations[notaMusical];

     if(estado == "sonido"){
	     if(Duracion >= conteoTiempos){
		     static int unavez = 0;
		     if(unavez==0){
			     unavez=1;tone(Zumbador, melody[notaMusical], Duracion*100);
		     }
		     conteoTiempos++;
		     if(Duracion == conteoTiempos){
			     conteoTiempos=0;
			     estado = "silencio";
			     unavez=0;
		     }
	     }
     }
     if(estado == "silencio"){
	     if(silencio >= conteoTiempos){
		     if(silencio == conteoTiempos){
			     conteoTiempos=0;
			     estado = "sonido";
			     notaMusical++;
			     if(notaMusical>=numero_notas_total){notaMusical=0;}
			     }else{
			     noTone(Zumbador);
			     conteoTiempos++;
		     }
	     }
     }
}

//sonido mostrar la independencia
void alarma4_NURCALL(void){
	static int numero_notas_total = 18;
	static int melody[] = {
		NOTE_A5,NOTE_A5,NOTE_A5,NOTE_F5,NOTE_C6,NOTE_A5,NOTE_F5,NOTE_C6,NOTE_A5
		,NOTE_E6,NOTE_E6,NOTE_E6,NOTE_F6,NOTE_C6,NOTE_A6,NOTE_F5,NOTE_C6,NOTE_A5
	};
	static int noteDurations[] = {
		4, 4, 4, 3, 2, 4, 3, 1, 4
		,4, 4, 4, 3, 2, 4, 3, 2, 4
	};

	static int silenceDurations[] = {
		0, 0, 0, 0, 0, 0, 0, 0, 4
		,0, 0, 0, 0, 0, 0, 0, 0, 4
	};
	
	
	//no modificar de aca en adelante
	static int notaMusical = 0;
	static int conteoTiempos = 0;
	static String estado = "sonido";
	int Duracion = noteDurations[notaMusical];
	int silencio = silenceDurations[notaMusical];

	if(estado == "sonido"){
		if(Duracion >= conteoTiempos){
			static int unavez = 0;
			if(unavez==0){
				unavez=1;tone(Zumbador, melody[notaMusical], Duracion*100);
			}
			conteoTiempos++;
			if(Duracion == conteoTiempos){
				conteoTiempos=0;
				estado = "silencio";
				unavez=0;
			}
		}
	}
	if(estado == "silencio"){
		if(silencio >= conteoTiempos){
			if(silencio == conteoTiempos){
				conteoTiempos=0;
				estado = "sonido";
				notaMusical++;
				if(notaMusical>=numero_notas_total){notaMusical=0;}
				}else{
				noTone(Zumbador);
				conteoTiempos++;
			}
		}
	}
}

//sonido cuando termina el setup
void alarma5_NURCALL(void){
	static int melody[] = {
		NOTE_C6,NOTE_A6,NOTE_F5,NOTE_C6,NOTE_A5
	};
	static int noteDurations[] = {
		10, 200, 50, 200, 50
	};

	static int silenceDurations[] = {
		50, 50, 10, 50, 10
	};
	
	digitalWrite(habilitadorZumbador, ONalarmasonora);
	for(int i=0;i<=5;i++){
		tone(Zumbador, melody[i], noteDurations[i]);
		delay(noteDurations[i]);
		noTone(Zumbador);
		delay(silenceDurations[i]);
	}
	digitalWrite(habilitadorZumbador, OFFalarmasonora);
}

//sonido cuando inicia el setup
void alarma6_NURCALL(void){
	static int melody[] = {
		NOTE_A5,NOTE_A5,NOTE_C6
	};
	static int noteDurations[] = {
		100, 200, 100
	};

	static int silenceDurations[] = {
		50, 100, 50
	};
		
	for(int i=0;i<=3;i++){
		digitalWrite(habilitadorZumbador, ONalarmasonora);
		tone(Zumbador, melody[i], noteDurations[i]);
		delay(noteDurations[i]);
		noTone(Zumbador);
		delay(silenceDurations[i]);
	}
	digitalWrite(habilitadorZumbador, OFFalarmasonora);
}

//sonido cuando encuentra un error en el setup
void alarma7_NURCALL(void){
	static int melody[] = {
		NOTE_C4, NOTE_G3, NOTE_G3, NOTE_A3, NOTE_G3
	};
	static int noteDurations[] = {
		100, 200, 100, 200, 100
	};

	static int silenceDurations[] = {
		50, 100, 50, 50, 50
	};
	
	
	for(int i=0;i<=5;i++){
		digitalWrite(habilitadorZumbador, ONalarmasonora);
		tone(Zumbador, melody[i], noteDurations[i]);
		delay(noteDurations[i]);
		noTone(Zumbador);
		delay(silenceDurations[i]);
	}
	digitalWrite(habilitadorZumbador, OFFalarmasonora);
}

void alarma8_NURCALL(void){
	static int numero_notas_total = 2;
	static int melody[] = {
		NOTE_A5, NOTE_C4
	};
	static int noteDurations[] = {
		3, 2
	};

	static int silenceDurations[] = {
		1, 0
	};
	
	
	//no modificar de aca en adelante
	static int notaMusical = 0;
	static int conteoTiempos = 0;
	static String estado = "sonido";
	int Duracion = noteDurations[notaMusical];
	int silencio = silenceDurations[notaMusical];

	if(estado == "sonido"){
		if(Duracion >= conteoTiempos){
			static int unavez = 0;
			if(unavez==0){
				unavez=1;tone(Zumbador, melody[notaMusical], Duracion*100);
			}
			conteoTiempos++;
			if(Duracion == conteoTiempos){
				conteoTiempos=0;
				estado = "silencio";
				unavez=0;
			}
		}
	}
	if(estado == "silencio"){
		if(silencio >= conteoTiempos){
			if(silencio == conteoTiempos){
				conteoTiempos=0;
				estado = "sonido";
				notaMusical++;
				if(notaMusical>=numero_notas_total){notaMusical=0;sonido_manual=0;}
				}else{
				noTone(Zumbador);
				conteoTiempos++;
			}
		}
	}
}

void alarma9_NURCALL(void){
	static int numero_notas_total = 2;
	static int melody[] = {
		NOTE_G5, NOTE_A4
	};
	static int noteDurations[] = {
		4, 4
	};

	static int silenceDurations[] = {
		1, 0
	};
	
	
	//no modificar de aca en adelante
	static int notaMusical = 0;
	static int conteoTiempos = 0;
	static String estado = "sonido";
	int Duracion = noteDurations[notaMusical];
	int silencio = silenceDurations[notaMusical];

	if(estado == "sonido"){
		if(Duracion >= conteoTiempos){
			static int unavez = 0;
			if(unavez==0){
				unavez=1;tone(Zumbador, melody[notaMusical], Duracion*100);
			}
			conteoTiempos++;
			if(Duracion == conteoTiempos){
				conteoTiempos=0;
				estado = "silencio";
				unavez=0;
			}
		}
	}
	if(estado == "silencio"){
		if(silencio >= conteoTiempos){
			if(silencio == conteoTiempos){
				conteoTiempos=0;
				estado = "sonido";
				notaMusical++;
				if(notaMusical>=numero_notas_total){notaMusical=0;sonido_manual=0;}
				}else{
				noTone(Zumbador);
				conteoTiempos++;
			}
		}
	}
}


void procesoSonido(int sel, int hab){	
	if(hab==1){	
		digitalWrite(habilitadorZumbador, ONalarmasonora);
		switch(sel){
			case 1:{
				alarma1_NURCALL();	//c�digo azul
			}break;
			case 2:{
				alarma2_NURCALL();	//WC
			}break;
			case 3:{
				alarma3_NURCALL();	//c�digo rojo
			}break;
			case 4:{
				alarma8_NURCALL();	//sonido manual
			}break;
			case 5:{
				alarma9_NURCALL();	//sonido manual
			}break;
		}
	}else{
		digitalWrite(habilitadorZumbador, OFFalarmasonora);	
		noTone(Zumbador);
	}
}


