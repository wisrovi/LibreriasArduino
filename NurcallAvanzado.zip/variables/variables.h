
/*
	Estas librerias, asi como el codigo de cada una, fueron creadas por 



	William S. Rodriguez Villamizar - ingeniero Electronico UDI

	La duracion de la creacion del codigo fue del 10MArzo2015 al 31Diciembre2015 

	en labores de la FCV (www.FCV.org)



	Gracias Dios Santisiomo por darme esta oportunidad, llenarme de bendiciones y darme las capacidades para lograr este proyecto en mi vida.

	Le agradezco a mi familia por acompa�arme en todo el camino, educarme en todos los aspectos, aconsejarme y acompa�arme.

	Le otorgo un agradecimiento especial al Ingeniero Miguel Angel Jurado Arenales - Ingeniero Electronico, quien vio en mi las capacidades, por las cuales me dio las primeras oportunidades para mostrar mis talentos, con lo cual, los inicios de mi carrera fueron gracias a �l.
*/


#define versionLampara 0.43


/////// parametros del sistema
int puerto = 0;
char URL[20];
String webService = "";
String Method1 = "";
String Method2 = "";
String Method3 = "";
int numero_Slaves = 0;
int number_WC = 0;
byte mac[6];
/////////////////////////////////////////
// pines salidas LEDs
#define LedRojo A0
#define LedAzul A1
#define LedVerde A2
#define LedBlanco A3
#define Zumbador 2
#define habilitadorZumbador 5
#define WC_1 A5
#define WC_2 A4
#define Ledconexion 9
#define PinNoIP 8
#define microSD 4
/////////////////////////////////////
#define LeerPulsadores 4
#define ApagarLeds 8
#define ArribaRojo 12
#define ArribaVerde 16
#define ArribaBlanco 20
#define ArribaAzul 24
#define ArribaWC 28
#define AbajoWC 32
#define ApagarLeds_menosWC 36
#define ArribaGris 40
#define ResetPaciente 90
#define ForcedTest 70
#define StopTest 80

/////////////////////////////////////////////////////////////////////
char AdressSlave[10] = { '0' , '1' , '2' , '3' , '4' , '5' , '6' , '7' , '8' , '9'};
int pulsadoresSlave[10] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 };
char vidaSlave[10] = { '0' , '0' , '0' , '0' , '0' , '0' , '0' , '0' , '0' , '0'  };
int lamparaRoja[10] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 };
int lamparaVerde[10] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 };
int lamparaBlanca[10] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 };
int lamparaAzul[10] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 };
int WC1 = 0;
int WC2 = 0;
static int memoriaWC2 = 0;
static int informado_sobre_WC1 = 0;
static int informado_sobre_WC2 = 0;

int apagar[10] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 };
int MAC_address[6] = {0, 0, 0, 0, 0, 0};




String token;
int esperarRespuestaWebServlet = 0;
//esta variable se activa y desactiva automaticamente segun las condiciones fisicas o logicas con la conexion con WebServlet
int independiente = 0;//esta variable me define si guardo en la microSD o envio al WebServlet (1-microSD / 0-WebServlet)
int parpadeo_independiente = 0;


int imprimir = 0;//imprimir? (1-si / 0-no)




static int FinretardoSlaves = 0;//necesario para lograr una comunicacion optima RS485
static int listaErrores[4] = {0,0,0,0};//inidspensable para localizar un error cuando se presente



#define pinControlRS485 3
long int conteoRuidoRS485 = 0;
long int conteoLecturasCorrectasRS485 = 0;
long int conteoLecturasEnviadosRS485 = 0;
int cerrarComunServidor = 0;

String reloj;
String relojAnterior;
int permisoEnviarWC = 0;
int permisoEnviarWC2 = 0;


int alarma = 0;
int sonido_manual = 0;

int refrescarPagina = 0;



/*
boolean ONalarmasonora = HIGH;
boolean OFFalarmasonora = LOW;
*/

boolean ONalarmasonora = LOW;
boolean OFFalarmasonora = HIGH;
byte ChipSonido = 0; //0=TDA8541 - 1=TS49901
	
	
	
	

int ultima_info[2] = {0,0};
String ultimaHora = "\n";

int imprimirEnviadoWebServlet = 1;



int bits[5]={0,0,0,0,0};
int bits2[5]={0,0,0,0,0};


int reinicioLampara = 0;	 
int inabilitarReset = 1;
String horaServidor = "";
String acumuladoMsgServidor = "";
 
byte temporalPinVidaServidor = 0;	 

int memoriaLlamados[6]={0,0,0,0,0,0};
int menuSecreto[2]={0,0};
int WC1_descompuesto = 0;
int WC2_descompuesto = 0;
int modoForzado = 0;
int EnvioRS485_modoForzado = 0;
 
//************************************************************************//

int iniciandoComoBasico = 0;
 
boolean banderaUsoEthernet = LOW;	 
boolean FuncionamientoSinServidor = LOW;
boolean FuncionamientoSinDHCP = LOW;
boolean NoPinVida = LOW;
boolean banderaActualizarHoraCuandoActualizoFecha = LOW;
boolean banderaActualizarMemoriaDate = LOW;